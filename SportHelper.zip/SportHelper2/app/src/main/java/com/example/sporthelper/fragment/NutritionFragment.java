package com.example.sporthelper.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sporthelper.R;
import com.example.sporthelper.activity.AuthActivity;
import com.example.sporthelper.activity.MainActivity;
import com.example.sporthelper.activity.ProfileActivity;
import com.example.sporthelper.activity.SettingsActivity;
import com.example.sporthelper.adapter.NutritionAdapter;
import com.example.sporthelper.databinding.FragmentNutritionBinding;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.NutritionLog;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.viewmodel.NutritionViewModel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class NutritionFragment extends Fragment {

    private FragmentNutritionBinding binding;
    private NutritionViewModel nutritionViewModel;
    private NutritionAdapter nutritionAdapter;

    private Long currentUserId;
    private LocalDate selectedDate;

    private final DateTimeFormatter uiFormatter =
            DateTimeFormatter.ofPattern("d MMMM", new Locale("ru"));

    public NutritionFragment() {
        super(R.layout.fragment_nutrition);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull android.view.LayoutInflater inflater,
                             @Nullable android.view.ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_nutrition, container, false);
        binding = FragmentNutritionBinding.bind(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SharedPreferencesManager prefsManager = SharedPreferencesManager.getInstance(requireContext());
        Profile currentUser = prefsManager.getUserProfile();

        if (currentUser == null || currentUser.getId() == null) {
            Toast.makeText(getContext(), "Ошибка: пользователь не найден", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(requireActivity(), AuthActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            requireActivity().overridePendingTransition(0, 0);
            requireActivity().finish();
            return;
        }

        currentUserId = currentUser.getId();
        selectedDate = LocalDate.now();

        initViewModels();
        setupRecyclerView();
        setupToolbar();
        setupUI();
        setupObservers();
        updateDateText();
        loadNutritionLogs();
    }

    private void initViewModels() {
        nutritionViewModel = new ViewModelProvider(this).get(NutritionViewModel.class);
    }

    private void setupRecyclerView() {
        nutritionAdapter = new NutritionAdapter(null);
        binding.nutritionRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.nutritionRecyclerView.setAdapter(nutritionAdapter);
    }

    private void setupToolbar() {
        boolean insideMain = requireActivity() instanceof MainActivity;

        if (!insideMain) {
            binding.toolbar.setVisibility(View.GONE);
            return;
        }

        binding.toolbar.setVisibility(View.VISIBLE);
        binding.toolbar.setTitle("SportHelper");

        binding.toolbar.post(() -> {
            if (binding.toolbar.getOverflowIcon() != null) {
                binding.toolbar.getOverflowIcon().mutate().setTint(Color.WHITE);
            }
        });

        binding.toolbar.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.action_profile) {
                Intent intent = new Intent(requireContext(), ProfileActivity.class);
                startActivity(intent);
                requireActivity().overridePendingTransition(0, 0);
                return true;
            }

            if (itemId == R.id.action_settings) {
                Intent intent = new Intent(requireContext(), SettingsActivity.class);
                startActivity(intent);
                requireActivity().overridePendingTransition(0, 0);
                return true;
            }

            return false;
        });
    }

    private void setupUI() {
        binding.analyzePhotoButton.setOnClickListener(v ->
                Toast.makeText(getContext(), "Анализ фото — пока в разработке", Toast.LENGTH_SHORT).show()
        );

        binding.addNutritionButton.setOnClickListener(v -> showAddNutritionDialog());

        binding.prevDayButton.setOnClickListener(v -> {
            selectedDate = selectedDate.minusDays(1);
            updateDateText();
            loadNutritionLogs();
        });

        binding.nextDayButton.setOnClickListener(v -> {
            selectedDate = selectedDate.plusDays(1);
            updateDateText();
            loadNutritionLogs();
        });
    }

    private void setupObservers() {
        nutritionViewModel.getNutritionLogs().observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case LOADING:
                    break;

                case SUCCESS:
                    List<NutritionLog> logs = resource.data;
                    nutritionAdapter.updateNutritionLogs(logs);
                    showEmptyState(logs == null || logs.isEmpty());
                    updateStats(logs);
                    break;

                case ERROR:
                    Toast.makeText(
                            getContext(),
                            resource.message != null ? resource.message : "Ошибка загрузки питания",
                            Toast.LENGTH_SHORT
                    ).show();
                    showEmptyState(true);
                    updateStats(null);
                    break;
            }
        });

        nutritionViewModel.getAddNutritionResult().observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case SUCCESS:
                    Toast.makeText(getContext(), "Запись питания добавлена", Toast.LENGTH_SHORT).show();
                    loadNutritionLogs();
                    break;

                case ERROR:
                    Toast.makeText(
                            getContext(),
                            resource.message != null ? resource.message : "Ошибка добавления",
                            Toast.LENGTH_SHORT
                    ).show();
                    break;

                case LOADING:
                    break;
            }
        });
    }

    private void loadNutritionLogs() {
        if (currentUserId == null) return;
        nutritionViewModel.loadNutritionLogs(currentUserId, selectedDate.toString());
    }

    private void updateDateText() {
        LocalDate today = LocalDate.now();
        LocalDate yesterday = today.minusDays(1);
        LocalDate tomorrow = today.plusDays(1);

        if (selectedDate.equals(today)) {
            binding.currentDateText.setText("Сегодня");
        } else if (selectedDate.equals(yesterday)) {
            binding.currentDateText.setText("Вчера");
        } else if (selectedDate.equals(tomorrow)) {
            binding.currentDateText.setText("Завтра");
        } else {
            binding.currentDateText.setText(selectedDate.format(uiFormatter));
        }
    }

    private void showAddNutritionDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_nutrition, null);

        Spinner mealTypeSpinner = dialogView.findViewById(R.id.mealTypeSpinner);
        EditText foodNameInput = dialogView.findViewById(R.id.foodNameInput);
        EditText caloriesInput = dialogView.findViewById(R.id.caloriesInput);
        EditText proteinInput = dialogView.findViewById(R.id.proteinInput);
        EditText fatInput = dialogView.findViewById(R.id.fatInput);
        EditText carbsInput = dialogView.findViewById(R.id.carbsInput);
        View cancelButton = dialogView.findViewById(R.id.cancelButton);
        View saveButton = dialogView.findViewById(R.id.saveButton);

        String[] mealTypes = {"Завтрак", "Обед", "Ужин", "Перекус"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                R.layout.item_spinner_nutrition,
                mealTypes
        );
        adapter.setDropDownViewResource(R.layout.item_spinner_nutrition_dropdown);
        mealTypeSpinner.setAdapter(adapter);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String foodName = safeText(foodNameInput);
            String caloriesStr = safeText(caloriesInput);
            String proteinStr = safeText(proteinInput);
            String fatStr = safeText(fatInput);
            String carbsStr = safeText(carbsInput);

            if (foodName.isEmpty()) {
                Toast.makeText(getContext(), "Введите название еды", Toast.LENGTH_SHORT).show();
                return;
            }

            if (caloriesStr.isEmpty()) {
                Toast.makeText(getContext(), "Введите калории", Toast.LENGTH_SHORT).show();
                return;
            }

            String mealTypeDb = mapMealTypeToDb(mealTypeSpinner.getSelectedItemPosition());

            int calories;
            double protein;
            double fat;
            double carbs;

            try {
                calories = Integer.parseInt(caloriesStr);
                protein = proteinStr.isEmpty() ? 0.0 : Double.parseDouble(proteinStr);
                fat = fatStr.isEmpty() ? 0.0 : Double.parseDouble(fatStr);
                carbs = carbsStr.isEmpty() ? 0.0 : Double.parseDouble(carbsStr);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Проверьте числовые поля", Toast.LENGTH_SHORT).show();
                return;
            }

            nutritionViewModel.addNutritionLog(
                    currentUserId,
                    selectedDate.toString(),
                    mealTypeDb,
                    foodName,
                    calories,
                    protein,
                    fat,
                    carbs
            );

            dialog.dismiss();
        });

        dialog.show();
    }

    private String safeText(EditText editText) {
        return editText.getText() != null ? editText.getText().toString().trim() : "";
    }

    private String mapMealTypeToDb(int position) {
        switch (position) {
            case 0:
                return "breakfast";
            case 1:
                return "lunch";
            case 2:
                return "dinner";
            case 3:
            default:
                return "snack";
        }
    }

    private void showEmptyState(boolean show) {
        binding.emptyState.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.nutritionRecyclerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private void updateStats(List<NutritionLog> logs) {
        if (logs == null || logs.isEmpty()) {
            binding.totalCaloriesText.setText("0");
            binding.totalProteinText.setText("0");
            binding.totalFatText.setText("0");
            binding.totalCarbsText.setText("0");
            return;
        }

        int totalCalories = 0;
        double totalProtein = 0;
        double totalFat = 0;
        double totalCarbs = 0;

        for (NutritionLog log : logs) {
            if (log.getCalories() != null) totalCalories += log.getCalories();
            if (log.getProtein() != null) totalProtein += log.getProtein();
            if (log.getFat() != null) totalFat += log.getFat();
            if (log.getCarbs() != null) totalCarbs += log.getCarbs();
        }

        binding.totalCaloriesText.setText(String.valueOf(totalCalories));
        binding.totalProteinText.setText(formatMacro(totalProtein));
        binding.totalFatText.setText(formatMacro(totalFat));
        binding.totalCarbsText.setText(formatMacro(totalCarbs));
    }

    private String formatMacro(double value) {
        if (value == (int) value) {
            return String.valueOf((int) value);
        }
        return String.format(Locale.getDefault(), "%.1f", value);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}