package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Chat;
import com.example.sporthelper.model.Message;
import com.example.sporthelper.model.Resource;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Request;

public class ChatRepository extends BaseRepository {

    private static final String TAG = "ChatRepository";
    private final ExecutorService executor = Executors.newFixedThreadPool(3);

    public ChatRepository(Context context) {
        super(context);
    }

    public LiveData<Resource<List<Chat>>> getChatsForUser(Long userId) {
        MutableLiveData<Resource<List<Chat>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String membersEndpoint = "chat_members?user_id=eq." + userId + "&select=chat_id";
                Request membersReq = createSupabaseRequest(membersEndpoint, "GET", null);
                String membersResp = executeRequest(membersReq);
                JsonArray membersArr = gson.fromJson(membersResp, JsonArray.class);

                if (membersArr == null || membersArr.size() == 0) {
                    result.postValue(Resource.success(new ArrayList<>()));
                    return;
                }

                StringBuilder chatIds = new StringBuilder();
                for (int i = 0; i < membersArr.size(); i++) {
                    if (i > 0) chatIds.append(",");
                    chatIds.append(membersArr.get(i).getAsJsonObject().get("chat_id").getAsLong());
                }

                String chatsEndpoint = "chats?id=in.(" + chatIds + ")&select=*";
                Request chatsReq = createSupabaseRequest(chatsEndpoint, "GET", null);
                String chatsResp = executeRequest(chatsReq);
                JsonArray chatsArr = gson.fromJson(chatsResp, JsonArray.class);

                List<Chat> chats = new ArrayList<>();
                if (chatsArr != null) {
                    for (int i = 0; i < chatsArr.size(); i++) {
                        Chat chat = parseChat(chatsArr.get(i).getAsJsonObject());
                        fillLastMessage(chat);
                        fillChatDisplayName(chat, userId);
                        chats.add(chat);
                    }
                }

                result.postValue(Resource.success(chats));
            } catch (Exception e) {
                Log.e(TAG, "getChatsForUser: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Long>> findUserByUsername(String username) {
        MutableLiveData<Resource<Long>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "profiles?username=eq." + username + "&select=id";
                Request req = createSupabaseRequest(endpoint, "GET", null);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                if (arr != null && arr.size() > 0) {
                    long foundUserId = arr.get(0).getAsJsonObject().get("id").getAsLong();
                    result.postValue(Resource.success(foundUserId));
                } else {
                    result.postValue(Resource.error("Пользователь не найден", null));
                }
            } catch (Exception e) {
                Log.e(TAG, "findUserByUsername: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Chat>> createPrivateChat(Long currentUserId, Long targetUserId) {
        MutableLiveData<Resource<Chat>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                JsonObject body = new JsonObject();
                body.addProperty("is_group", false);
                body.addProperty("created_by", currentUserId);

                Request req = createSupabaseRequest("chats?select=*", "POST", body);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                if (arr == null || arr.size() == 0) {
                    result.postValue(Resource.error("Ошибка создания чата", null));
                    return;
                }

                Chat chat = parseChat(arr.get(0).getAsJsonObject());
                addMember(chat.getId(), currentUserId);
                addMember(chat.getId(), targetUserId);

                String nameEndpoint = "profiles?id=eq." + targetUserId + "&select=username";
                Request nameReq = createSupabaseRequest(nameEndpoint, "GET", null);
                String nameResp = executeRequest(nameReq);
                JsonArray nameArr = gson.fromJson(nameResp, JsonArray.class);

                if (nameArr != null && nameArr.size() > 0) {
                    String username = nameArr.get(0).getAsJsonObject().get("username").getAsString();
                    chat.setName(username);
                }

                result.postValue(Resource.success(chat));
            } catch (Exception e) {
                Log.e(TAG, "createPrivateChat: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Chat>> createGroupChat(Long creatorId, String groupName) {
        MutableLiveData<Resource<Chat>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String inviteCode = generateInviteCode();

                JsonObject body = new JsonObject();
                body.addProperty("name", groupName);
                body.addProperty("is_group", true);
                body.addProperty("created_by", creatorId);
                body.addProperty("invite_code", inviteCode);

                Request req = createSupabaseRequest("chats?select=*", "POST", body);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                if (arr == null || arr.size() == 0) {
                    result.postValue(Resource.error("Ошибка создания группы", null));
                    return;
                }

                Chat chat = parseChat(arr.get(0).getAsJsonObject());
                addMember(chat.getId(), creatorId);
                result.postValue(Resource.success(chat));
            } catch (Exception e) {
                Log.e(TAG, "createGroupChat: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> joinChatByCode(Long userId, String code) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "chats?invite_code=eq." + code + "&select=id";
                Request req = createSupabaseRequest(endpoint, "GET", null);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                if (arr == null || arr.size() == 0) {
                    result.postValue(Resource.error("Неверный код приглашения", null));
                    return;
                }

                long chatId = arr.get(0).getAsJsonObject().get("id").getAsLong();
                addMember(chatId, userId);
                result.postValue(Resource.success(true));
            } catch (Exception e) {
                Log.e(TAG, "joinChatByCode: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<List<String>>> getChatMembers(Long chatId) {
        MutableLiveData<Resource<List<String>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String membersEndpoint = "chat_members?chat_id=eq." + chatId + "&select=user_id";
                Request membersReq = createSupabaseRequest(membersEndpoint, "GET", null);
                String membersResp = executeRequest(membersReq);
                JsonArray membersArr = gson.fromJson(membersResp, JsonArray.class);

                if (membersArr == null || membersArr.size() == 0) {
                    result.postValue(Resource.success(new ArrayList<>()));
                    return;
                }

                StringBuilder userIds = new StringBuilder();
                for (int i = 0; i < membersArr.size(); i++) {
                    if (i > 0) userIds.append(",");
                    userIds.append(membersArr.get(i).getAsJsonObject().get("user_id").getAsLong());
                }

                String profilesEndpoint = "profiles?id=in.(" + userIds + ")&select=username";
                Request profilesReq = createSupabaseRequest(profilesEndpoint, "GET", null);
                String profilesResp = executeRequest(profilesReq);
                JsonArray profilesArr = gson.fromJson(profilesResp, JsonArray.class);

                List<String> members = new ArrayList<>();
                if (profilesArr != null) {
                    for (int i = 0; i < profilesArr.size(); i++) {
                        JsonObject obj = profilesArr.get(i).getAsJsonObject();
                        if (obj.has("username") && !obj.get("username").isJsonNull()) {
                            members.add(obj.get("username").getAsString());
                        }
                    }
                }

                result.postValue(Resource.success(members));
            } catch (Exception e) {
                Log.e(TAG, "getChatMembers: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<String>> getInviteCode(Long chatId) {
        MutableLiveData<Resource<String>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "chats?id=eq." + chatId + "&select=invite_code";
                Request req = createSupabaseRequest(endpoint, "GET", null);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                if (arr != null && arr.size() > 0) {
                    JsonObject obj = arr.get(0).getAsJsonObject();
                    if (obj.has("invite_code") && !obj.get("invite_code").isJsonNull()) {
                        result.postValue(Resource.success(obj.get("invite_code").getAsString()));
                        return;
                    }
                }

                String newCode = generateInviteCode();
                JsonObject patchBody = new JsonObject();
                patchBody.addProperty("invite_code", newCode);

                Request patchReq = createSupabaseRequest("chats?id=eq." + chatId, "PATCH", patchBody);
                String patchResp = executeRequest(patchReq);
                Log.d(TAG, "getInviteCode patch response: " + patchResp);

                result.postValue(Resource.success(newCode));
            } catch (Exception e) {
                Log.e(TAG, "getInviteCode: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<List<Message>>> getMessages(Long chatId) {
        MutableLiveData<Resource<List<Message>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "messages?chat_id=eq." + chatId + "&order=created_at.asc&select=*";
                Request req = createSupabaseRequest(endpoint, "GET", null);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                List<Message> messages = new ArrayList<>();
                if (arr != null) {
                    for (int i = 0; i < arr.size(); i++) {
                        messages.add(parseMessage(arr.get(i).getAsJsonObject()));
                    }
                }

                result.postValue(Resource.success(messages));
            } catch (Exception e) {
                Log.e(TAG, "getMessages: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Message>> sendMessage(Long chatId, Long senderId, String text, Long replyToId) {
        MutableLiveData<Resource<Message>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                JsonObject body = new JsonObject();
                body.addProperty("chat_id", chatId);
                body.addProperty("sender_id", senderId);
                body.addProperty("message_text", text);
                if (replyToId != null) {
                    body.addProperty("reply_to_id", replyToId);
                }

                Request req = createSupabaseRequest("messages?select=*", "POST", body);
                String resp = executeRequest(req);
                JsonArray arr = gson.fromJson(resp, JsonArray.class);

                if (arr != null && arr.size() > 0) {
                    result.postValue(Resource.success(parseMessage(arr.get(0).getAsJsonObject())));
                } else {
                    result.postValue(Resource.error("Ошибка отправки", null));
                }
            } catch (Exception e) {
                Log.e(TAG, "sendMessage: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> deleteMessage(Long messageId) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                Request req = createSupabaseRequest("messages?id=eq." + messageId, "DELETE", null);
                String resp = executeRequest(req);
                Log.d(TAG, "deleteMessage response: " + resp);

                result.postValue(Resource.success(true));
            } catch (Exception e) {
                Log.e(TAG, "deleteMessage: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> editMessage(Long messageId, String newText) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                JsonObject body = new JsonObject();
                body.addProperty("message_text", newText);

                Request req = createSupabaseRequest("messages?id=eq." + messageId, "PATCH", body);
                String resp = executeRequest(req);
                Log.d(TAG, "editMessage response: " + resp);

                result.postValue(Resource.success(true));
            } catch (Exception e) {
                Log.e(TAG, "editMessage: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> updateGroupName(Long chatId, String newName) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                Log.d(TAG, "updateGroupName START chatId=" + chatId + " newName=" + newName);

                JsonObject body = new JsonObject();
                body.addProperty("name", newName);

                String patchEndpoint = "chats?id=eq." + chatId + "&select=*";
                Request patchReq = createSupabaseRequest(patchEndpoint, "PATCH", body);
                String patchResp = executeRequest(patchReq);

                Log.d(TAG, "updateGroupName PATCH endpoint: " + patchEndpoint);
                Log.d(TAG, "updateGroupName PATCH body: " + body);
                Log.d(TAG, "updateGroupName PATCH response: " + patchResp);

                String checkEndpoint = "chats?id=eq." + chatId + "&select=id,name,created_by,is_group";
                Request checkReq = createSupabaseRequest(checkEndpoint, "GET", null);
                String checkResp = executeRequest(checkReq);

                Log.d(TAG, "updateGroupName CHECK response: " + checkResp);

                result.postValue(Resource.success(true));
            } catch (Exception e) {
                Log.e(TAG, "updateGroupName ERROR: " + e.getMessage(), e);
                result.postValue(Resource.error("updateGroupName: " + e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> leaveChat(Long chatId, Long userId) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "chat_members?chat_id=eq." + chatId + "&user_id=eq." + userId;
                Request req = createSupabaseRequest(endpoint, "DELETE", null);
                String resp = executeRequest(req);
                Log.d(TAG, "leaveChat response: " + resp);

                result.postValue(Resource.success(true));
            } catch (Exception e) {
                Log.e(TAG, "leaveChat: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> deleteGroup(Long chatId) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                Request req = createSupabaseRequest("chats?id=eq." + chatId, "DELETE", null);
                String resp = executeRequest(req);
                Log.d(TAG, "deleteGroup response: " + resp);

                result.postValue(Resource.success(true));
            } catch (Exception e) {
                Log.e(TAG, "deleteGroup: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });

        return result;
    }

    private void addMember(Long chatId, Long userId) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("chat_id", chatId);
        body.addProperty("user_id", userId);

        Request req = createSupabaseRequest("chat_members", "POST", body);
        String resp = executeRequest(req);
        Log.d(TAG, "addMember response: " + resp);
    }

    private void fillLastMessage(Chat chat) {
        try {
            String endpoint = "messages?chat_id=eq." + chat.getId()
                    + "&order=created_at.desc&limit=1&select=message_text,created_at";
            Request req = createSupabaseRequest(endpoint, "GET", null);
            String resp = executeRequest(req);
            JsonArray arr = gson.fromJson(resp, JsonArray.class);

            if (arr != null && arr.size() > 0) {
                JsonObject obj = arr.get(0).getAsJsonObject();

                if (obj.has("message_text") && !obj.get("message_text").isJsonNull()) {
                    chat.setLastMessage(obj.get("message_text").getAsString());
                } else {
                    chat.setLastMessage("Нет сообщений");
                }

                if (obj.has("created_at") && !obj.get("created_at").isJsonNull()) {
                    chat.setLastMessageTime(obj.get("created_at").getAsString());
                }
            } else {
                chat.setLastMessage("Нет сообщений");
                chat.setLastMessageTime("");
            }
        } catch (Exception e) {
            Log.e(TAG, "fillLastMessage: " + e.getMessage(), e);
            if (chat.getLastMessage() == null) chat.setLastMessage("Нет сообщений");
            if (chat.getLastMessageTime() == null) chat.setLastMessageTime("");
        }
    }

    private void fillChatDisplayName(Chat chat, Long currentUserId) {
        try {
            if (Boolean.TRUE.equals(chat.getIsGroup())) {
                if (chat.getName() == null || chat.getName().trim().isEmpty()) {
                    chat.setName("Группа");
                }
                return;
            }

            String membersEndpoint = "chat_members?chat_id=eq." + chat.getId() + "&select=user_id";
            Request membersReq = createSupabaseRequest(membersEndpoint, "GET", null);
            String membersResp = executeRequest(membersReq);
            JsonArray membersArr = gson.fromJson(membersResp, JsonArray.class);

            Long otherUserId = null;
            if (membersArr != null) {
                for (int i = 0; i < membersArr.size(); i++) {
                    long uid = membersArr.get(i).getAsJsonObject().get("user_id").getAsLong();
                    if (!Long.valueOf(uid).equals(currentUserId)) {
                        otherUserId = uid;
                        break;
                    }
                }
            }

            if (otherUserId == null) {
                if (chat.getName() == null || chat.getName().trim().isEmpty()) {
                    chat.setName("Личный чат");
                }
                return;
            }

            String endpoint = "profiles?id=eq." + otherUserId + "&select=username";
            Request req = createSupabaseRequest(endpoint, "GET", null);
            String resp = executeRequest(req);
            JsonArray arr = gson.fromJson(resp, JsonArray.class);

            if (arr != null && arr.size() > 0) {
                JsonObject obj = arr.get(0).getAsJsonObject();
                if (obj.has("username") && !obj.get("username").isJsonNull()) {
                    chat.setName(obj.get("username").getAsString());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "fillChatDisplayName: " + e.getMessage(), e);
        }
    }

    private Chat parseChat(JsonObject obj) {
        Chat chat = new Chat();

        if (obj.has("id") && !obj.get("id").isJsonNull())
            chat.setId(obj.get("id").getAsLong());
        if (obj.has("name") && !obj.get("name").isJsonNull())
            chat.setName(obj.get("name").getAsString());
        if (obj.has("is_group") && !obj.get("is_group").isJsonNull())
            chat.setGroup(obj.get("is_group").getAsBoolean());
        if (obj.has("created_by") && !obj.get("created_by").isJsonNull())
            chat.setCreatedBy(obj.get("created_by").getAsLong());
        if (obj.has("invite_code") && !obj.get("invite_code").isJsonNull())
            chat.setInviteCode(obj.get("invite_code").getAsString());
        if (obj.has("created_at") && !obj.get("created_at").isJsonNull())
            chat.setCreatedAt(obj.get("created_at").getAsString());

        return chat;
    }

    private Message parseMessage(JsonObject obj) {
        Message msg = new Message();

        if (obj.has("id") && !obj.get("id").isJsonNull())
            msg.setId(obj.get("id").getAsLong());
        if (obj.has("chat_id") && !obj.get("chat_id").isJsonNull())
            msg.setChatId(obj.get("chat_id").getAsLong());
        if (obj.has("sender_id") && !obj.get("sender_id").isJsonNull())
            msg.setSenderId(obj.get("sender_id").getAsLong());
        if (obj.has("message_text") && !obj.get("message_text").isJsonNull())
            msg.setContent(obj.get("message_text").getAsString());
        if (obj.has("created_at") && !obj.get("created_at").isJsonNull())
            msg.setCreatedAt(obj.get("created_at").getAsString());
        if (obj.has("reply_to_id") && !obj.get("reply_to_id").isJsonNull())
            msg.setReplyToId(obj.get("reply_to_id").getAsLong());
        if (obj.has("sender_username") && !obj.get("sender_username").isJsonNull())
            msg.setSenderUsername(obj.get("sender_username").getAsString());
        if (obj.has("reply_to_text") && !obj.get("reply_to_text").isJsonNull())
            msg.setReplyToText(obj.get("reply_to_text").getAsString());
        if (obj.has("reply_to_username") && !obj.get("reply_to_username").isJsonNull())
            msg.setReplyToUsername(obj.get("reply_to_username").getAsString());

        return msg;
    }

    private String generateInviteCode() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 8; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }

        return sb.toString();
    }
}