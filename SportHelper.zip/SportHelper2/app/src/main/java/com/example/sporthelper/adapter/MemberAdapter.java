package com.example.sporthelper.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;

import java.util.ArrayList;
import java.util.List;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.MemberViewHolder> {

    private List<String> members = new ArrayList<>();

    public void setMembers(List<String> members) {
        this.members = members != null ? members : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_member, parent, false);
        return new MemberViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MemberViewHolder holder, int position) {
        String member = members.get(position);
        holder.memberNameText.setText(member != null ? member : "Пользователь");

        String avatar = "U";
        if (member != null && !member.trim().isEmpty()) {
            avatar = member.substring(0, 1).toUpperCase();
        }
        holder.memberAvatarText.setText(avatar);
    }

    @Override
    public int getItemCount() {
        return members.size();
    }

    static class MemberViewHolder extends RecyclerView.ViewHolder {
        TextView memberAvatarText;
        TextView memberNameText;

        MemberViewHolder(@NonNull View itemView) {
            super(itemView);
            memberAvatarText = itemView.findViewById(R.id.memberAvatarText);
            memberNameText = itemView.findViewById(R.id.memberNameText);
        }
    }
}