package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.NutritionLog;
import com.example.sporthelper.model.Resource;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Request;

public class NutritionRepository extends BaseRepository {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Gson gson = new Gson();

    public NutritionRepository(Context context) {
        super(context);
    }

    public LiveData<Resource<List<NutritionLog>>> getNutritionLogs(Long userId, String date) {
        MutableLiveData<Resource<List<NutritionLog>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "nutrition_logs?user_id=eq." + userId
                        + "&log_date=eq." + date
                        + "&select=*"
                        + "&order=id.desc";

                Request request = createSupabaseRequest(endpoint, "GET", null);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                List<NutritionLog> logs = new ArrayList<>();

                for (int i = 0; i < jsonArray.size(); i++) {
                    JsonObject logObj = jsonArray.get(i).getAsJsonObject();
                    logs.add(parseNutritionLog(logObj));
                }

                result.postValue(Resource.success(logs));

            } catch (Exception e) {
                Log.e("NutritionRepository", "Ошибка загрузки питания: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка загрузки: " + e.getMessage(), new ArrayList<>()));
            }
        });

        return result;
    }

    public LiveData<Resource<Boolean>> addNutritionLog(Long userId,
                                                       String logDate,
                                                       String mealType,
                                                       String foodName,
                                                       int calories,
                                                       double protein,
                                                       double fat,
                                                       double carbs) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                JsonObject body = new JsonObject();
                body.addProperty("user_id", userId);
                body.addProperty("log_date", logDate);
                body.addProperty("meal_type", mealType);
                body.addProperty("food_name", foodName);
                body.addProperty("calories", calories);
                body.addProperty("protein", protein);
                body.addProperty("fat", fat);
                body.addProperty("carbs", carbs);

                Request request = createSupabaseRequest("nutrition_logs?select=*", "POST", body);
                executeRequest(request);

                result.postValue(Resource.success(true));

            } catch (Exception e) {
                Log.e("NutritionRepository", "Ошибка добавления питания: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка добавления: " + e.getMessage(), false));
            }
        });

        return result;
    }

    public LiveData<Resource<String>> analyzeFoodPhoto(byte[] imageData) {
        MutableLiveData<Resource<String>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));
                Thread.sleep(2500);
                result.postValue(Resource.success("Распознавание еды пока в разработке"));
            } catch (Exception e) {
                Log.e("NutritionRepository", "Ошибка анализа фото: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка анализа фото", null));
            }
        });

        return result;
    }

    private NutritionLog parseNutritionLog(JsonObject logObj) {
        NutritionLog log = new NutritionLog();

        if (logObj.has("id") && !logObj.get("id").isJsonNull()) {
            log.setId(logObj.get("id").getAsLong());
        }
        if (logObj.has("user_id") && !logObj.get("user_id").isJsonNull()) {
            log.setUserId(logObj.get("user_id").getAsLong());
        }
        if (logObj.has("log_date") && !logObj.get("log_date").isJsonNull()) {
            log.setLogDate(logObj.get("log_date").getAsString());
        }
        if (logObj.has("meal_type") && !logObj.get("meal_type").isJsonNull()) {
            log.setMealType(logObj.get("meal_type").getAsString());
        }
        if (logObj.has("food_name") && !logObj.get("food_name").isJsonNull()) {
            log.setFoodName(logObj.get("food_name").getAsString());
        }
        if (logObj.has("calories") && !logObj.get("calories").isJsonNull()) {
            log.setCalories(logObj.get("calories").getAsInt());
        }
        if (logObj.has("protein") && !logObj.get("protein").isJsonNull()) {
            log.setProtein(logObj.get("protein").getAsDouble());
        }
        if (logObj.has("fat") && !logObj.get("fat").isJsonNull()) {
            log.setFat(logObj.get("fat").getAsDouble());
        }
        if (logObj.has("carbs") && !logObj.get("carbs").isJsonNull()) {
            log.setCarbs(logObj.get("carbs").getAsDouble());
        }

        return log;
    }
}