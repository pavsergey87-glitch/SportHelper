package com.example.sporthelper.activity;

import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.adapter.ChatAdapter;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Chat;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.viewmodel.ChatViewModel;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

public class ForwardActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE_TEXT = "forward_message_text";
    public static final String EXTRA_SENDER_USERNAME = "forward_sender_username";

    private ChatViewModel chatViewModel;
    private Profile currentUser;
    private String messageText;
    private String senderUsername;

    private Switch hideNameSwitch;
    private TextView forwardPreviewText;
    private RecyclerView chatsRecyclerView;
    private ChatAdapter chatAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forward);

        messageText = getIntent().getStringExtra(EXTRA_MESSAGE_TEXT);
        senderUsername = getIntent().getStringExtra(EXTRA_SENDER_USERNAME);

        SharedPreferencesManager prefsManager = SharedPreferencesManager.getInstance(this);
        currentUser = prefsManager.getUserProfile();
        if (currentUser == null || messageText == null) {
            finish();
            return;
        }

        initViews();
        initViewModels();
        setupRecyclerView();
        loadChats();
    }

    private void initViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle("Переслать в...");
            setSupportActionBar(toolbar);
            toolbar.setNavigationOnClickListener(v -> finish());
        }
        hideNameSwitch = findViewById(R.id.hideNameSwitch);
        forwardPreviewText = findViewById(R.id.forwardPreviewText);
        chatsRecyclerView = findViewById(R.id.chatsRecyclerView);

        // Показываем превью
        updatePreview();
        hideNameSwitch.setOnCheckedChangeListener((btn, checked) -> updatePreview());
    }

    private void updatePreview() {
        boolean hideName = hideNameSwitch.isChecked();
        if (hideName || senderUsername == null || senderUsername.isEmpty()) {
            forwardPreviewText.setText("↗️ " + messageText);
        } else {
            forwardPreviewText.setText("↗️ " + senderUsername + ":\n" + messageText);
        }
    }

    private void initViewModels() {
        chatViewModel = new ViewModelProvider(this).get(ChatViewModel.class);
    }

    private void setupRecyclerView() {
        chatAdapter = new ChatAdapter(null, chat -> sendForward(chat));
        chatsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatsRecyclerView.setAdapter(chatAdapter);
    }

    private void loadChats() {
        chatViewModel.loadChats(currentUser.getId());
        chatViewModel.getChats().observe(this, resource -> {
            if (resource == null) return;
            if (resource.status == Resource.Status.SUCCESS) {
                List<Chat> chats = resource.data;
                chatAdapter.updateChats(chats);
            }
        });
    }

    private void sendForward(Chat targetChat) {
        boolean hideName = hideNameSwitch.isChecked();
        String textToSend;
        if (hideName || senderUsername == null || senderUsername.isEmpty()) {
            textToSend = "↗️ " + messageText;
        } else {
            textToSend = "↗️ " + senderUsername + ":\n" + messageText;
        }

        chatViewModel.sendMessage(targetChat.getId(), currentUser.getId(), textToSend, null);
        chatViewModel.getSendResult().observe(this, resource -> {
            if (resource == null) return;
            if (resource.status == Resource.Status.LOADING) return;
            if (resource.status == Resource.Status.SUCCESS) {
                Toast.makeText(this, "Переслано в " + targetChat.getName(), Toast.LENGTH_SHORT).show();
                finish();
            } else if (resource.status == Resource.Status.ERROR) {
                Toast.makeText(this, "Ошибка: " + resource.message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
