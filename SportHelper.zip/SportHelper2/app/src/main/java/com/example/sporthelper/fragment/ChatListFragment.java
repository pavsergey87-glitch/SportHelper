package com.example.sporthelper.fragment;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.activity.ChatActivity;
import com.example.sporthelper.activity.MainActivity;
import com.example.sporthelper.activity.ProfileActivity;
import com.example.sporthelper.activity.SettingsActivity;
import com.example.sporthelper.adapter.ChatAdapter;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Chat;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.util.ChatNotificationHelper;
import com.example.sporthelper.viewmodel.ChatViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.List;

public class ChatListFragment extends Fragment {

    private ChatViewModel chatViewModel;
    private ChatAdapter chatAdapter;
    private Profile currentUser;

    private RecyclerView chatsRecyclerView;
    private LinearLayout emptyState;
    private FloatingActionButton newChatFab;
    private MaterialToolbar toolbar;

    private final HashMap<Long, String> lastKnownMessages = new HashMap<>();
    private boolean firstChatsLoad = true;

    private final ActivityResultLauncher<Intent> chatActivityLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> loadChats()
            );

    public ChatListFragment() {
        super(R.layout.fragment_chat_list);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadChats();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        currentUser = SharedPreferencesManager.getInstance(requireContext()).getUserProfile();
        if (currentUser == null) {
            Toast.makeText(requireContext(), "Ошибка авторизации", Toast.LENGTH_SHORT).show();
            return;
        }

        initViews(view);
        initViewModel();
        ChatNotificationHelper.createNotificationChannel(requireContext());
        setupToolbar();
        setupRecyclerView();
        setupUI();
        setupObservers();
        loadChats();
    }

    private void initViews(@NonNull View view) {
        toolbar = view.findViewById(R.id.toolbar);
        chatsRecyclerView = view.findViewById(R.id.chatsRecyclerView);
        emptyState = view.findViewById(R.id.emptyState);
        newChatFab = view.findViewById(R.id.newChatFab);
    }

    private void initViewModel() {
        chatViewModel = new ViewModelProvider(this).get(ChatViewModel.class);
    }

    private void setupToolbar() {
        boolean insideMain = requireActivity() instanceof MainActivity;

        if (!insideMain) {
            toolbar.setVisibility(View.GONE);
            return;
        }

        toolbar.setVisibility(View.VISIBLE);
        toolbar.setTitle("SportHelper");

        toolbar.post(() -> {
            if (toolbar.getOverflowIcon() != null) {
                toolbar.getOverflowIcon().mutate().setTint(Color.WHITE);
            }
        });

        toolbar.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.action_profile) {
                Intent intent = new Intent(requireContext(), ProfileActivity.class);
                startActivity(intent);
                requireActivity().overridePendingTransition(0, 0);
                return true;
            }

            if (itemId == R.id.action_settings) {
                Intent intent = new Intent(requireContext(), SettingsActivity.class);
                startActivity(intent);
                requireActivity().overridePendingTransition(0, 0);
                return true;
            }

            return false;
        });
    }

    private void setupRecyclerView() {
        chatAdapter = new ChatAdapter(null, chat -> {
            Intent intent = new Intent(requireContext(), ChatActivity.class);
            intent.putExtra("chat", chat);
            intent.putExtra("currentUserId", currentUser.getId());
            intent.putExtra("currentUsername", currentUser.getUsername());
            chatActivityLauncher.launch(intent);
            requireActivity().overridePendingTransition(0, 0);
        });

        chatsRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        chatsRecyclerView.setAdapter(chatAdapter);
    }

    private void setupUI() {
        newChatFab.setOnClickListener(v -> showChatTypeDialog());
    }

    private void setupObservers() {
        chatViewModel.getChats().observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case SUCCESS:
                    List<Chat> chats = resource.data;
                    handleChatNotifications(chats);

                    chatAdapter.updateChats(chats);

                    boolean empty = chats == null || chats.isEmpty();
                    emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
                    chatsRecyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
                    break;

                case ERROR:
                    Toast.makeText(requireContext(), "Ошибка: " + resource.message, Toast.LENGTH_SHORT).show();
                    break;

                case LOADING:
                    break;
            }
        });
    }

    private void handleChatNotifications(List<Chat> chats) {
        if (chats == null || currentUser == null) return;

        SharedPreferencesManager prefs = SharedPreferencesManager.getInstance(requireContext());

        for (Chat chat : chats) {
            if (chat == null || chat.getId() == null) continue;

            String newLastMessage = chat.getLastMessage() != null ? chat.getLastMessage() : "";
            String oldLastMessage = lastKnownMessages.get(chat.getId());

            boolean changed = oldLastMessage != null && !oldLastMessage.equals(newLastMessage);

            if (!firstChatsLoad
                    && changed
                    && prefs.areGlobalChatNotificationsEnabled()
                    && prefs.isChatNotificationsEnabled(chat.getId())) {

                Long openChatId = prefs.getOpenChatId();
                boolean sameOpenChat = openChatId != null && openChatId.equals(chat.getId());

                if (!sameOpenChat
                        && !newLastMessage.trim().isEmpty()
                        && !"Нет сообщений".equals(newLastMessage)) {

                    String senderName = chat.getName() != null ? chat.getName() : "Чат";

                    ChatNotificationHelper.showChatNotification(
                            requireContext(),
                            chat,
                            senderName,
                            newLastMessage
                    );
                }
            }

            lastKnownMessages.put(chat.getId(), newLastMessage);
        }

        firstChatsLoad = false;
    }

    private void loadChats() {
        chatViewModel.loadChats(currentUser.getId());
    }

    private void showChatTypeDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_chat_type, null);
        View privateChatCard = dialogView.findViewById(R.id.privateChatCard);
        View groupChatCard = dialogView.findViewById(R.id.groupChatCard);
        View joinCodeCard = dialogView.findViewById(R.id.joinCodeCard);
        View cancelButton = dialogView.findViewById(R.id.cancelButton);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        privateChatCard.setOnClickListener(v -> {
            dialog.dismiss();
            showPrivateChatDialog();
        });

        groupChatCard.setOnClickListener(v -> {
            dialog.dismiss();
            showGroupChatDialog();
        });

        joinCodeCard.setOnClickListener(v -> {
            dialog.dismiss();
            showJoinByCodeDialog();
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void showPrivateChatDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_private_chat, null);
        TextInputEditText usernameInput = dialogView.findViewById(R.id.usernameInput);
        View cancelButton = dialogView.findViewById(R.id.cancelButton);
        View startButton = dialogView.findViewById(R.id.startButton);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        startButton.setOnClickListener(v -> {
            String username = usernameInput.getText() != null
                    ? usernameInput.getText().toString().trim()
                    : "";

            if (username.isEmpty()) {
                Toast.makeText(requireContext(), "Введите username", Toast.LENGTH_SHORT).show();
                return;
            }

            if (username.equals(currentUser.getUsername())) {
                Toast.makeText(requireContext(), "Нельзя создать чат с самим собой", Toast.LENGTH_SHORT).show();
                return;
            }

            dialog.dismiss();
            findUserAndCreatePrivateChat(username);
        });

        dialog.show();
    }

    private void findUserAndCreatePrivateChat(String username) {
        chatViewModel.findUserByUsername(username);
        chatViewModel.getFindUserResult().observe(getViewLifecycleOwner(), new Observer<Resource<Long>>() {
            @Override
            public void onChanged(Resource<Long> resource) {
                if (resource == null) return;
                if (resource.status == Resource.Status.LOADING) return;

                chatViewModel.getFindUserResult().removeObserver(this);

                if (resource.status == Resource.Status.SUCCESS && resource.data != null) {
                    chatViewModel.createPrivateChat(currentUser.getId(), resource.data);

                    chatViewModel.getCreateChatResult().observe(getViewLifecycleOwner(), new Observer<Resource<Chat>>() {
                        @Override
                        public void onChanged(Resource<Chat> chatResource) {
                            if (chatResource == null) return;
                            if (chatResource.status == Resource.Status.LOADING) return;

                            chatViewModel.getCreateChatResult().removeObserver(this);

                            if (chatResource.status == Resource.Status.SUCCESS && chatResource.data != null) {
                                Toast.makeText(requireContext(), "Чат открыт!", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(requireContext(), ChatActivity.class);
                                intent.putExtra("chat", chatResource.data);
                                intent.putExtra("currentUserId", currentUser.getId());
                                intent.putExtra("currentUsername", currentUser.getUsername());
                                chatActivityLauncher.launch(intent);
                                requireActivity().overridePendingTransition(0, 0);

                                loadChats();
                            } else {
                                Toast.makeText(
                                        requireContext(),
                                        "Ошибка: " + chatResource.message,
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                    });
                } else {
                    Toast.makeText(
                            requireContext(),
                            "Пользователь «" + username + "» не найден",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }
        });
    }

    private void showGroupChatDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_create_group, null);
        TextInputEditText groupNameInput = dialogView.findViewById(R.id.groupNameInput);
        View cancelButton = dialogView.findViewById(R.id.cancelButton);
        View createButton = dialogView.findViewById(R.id.createButton);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        createButton.setOnClickListener(v -> {
            String groupName = groupNameInput.getText() != null
                    ? groupNameInput.getText().toString().trim()
                    : "";

            if (groupName.isEmpty()) {
                Toast.makeText(requireContext(), "Введите название", Toast.LENGTH_SHORT).show();
                return;
            }

            dialog.dismiss();

            chatViewModel.createGroupChat(currentUser.getId(), groupName);
            chatViewModel.getCreateChatResult().observe(getViewLifecycleOwner(), new Observer<Resource<Chat>>() {
                @Override
                public void onChanged(Resource<Chat> resource) {
                    if (resource == null) return;
                    if (resource.status == Resource.Status.LOADING) return;

                    chatViewModel.getCreateChatResult().removeObserver(this);

                    if (resource.status == Resource.Status.SUCCESS && resource.data != null) {
                        loadChats();
                        showGroupCreatedDialog(resource.data);
                    } else {
                        Toast.makeText(
                                requireContext(),
                                "Ошибка: " + resource.message,
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
            });
        });

        dialog.show();
    }

    private void showGroupCreatedDialog(Chat chat) {
        chatViewModel.getInviteCode(chat.getId());
        chatViewModel.getInviteCodeResult().observe(getViewLifecycleOwner(), new Observer<Resource<String>>() {
            @Override
            public void onChanged(Resource<String> resource) {
                if (resource == null) return;
                if (resource.status == Resource.Status.LOADING) return;

                chatViewModel.getInviteCodeResult().removeObserver(this);

                if (resource.status != Resource.Status.SUCCESS || resource.data == null) return;

                String code = resource.data;

                View dialogView = getLayoutInflater().inflate(R.layout.dialog_group_created, null);
                TextView inviteCodeText = dialogView.findViewById(R.id.inviteCodeText);
                View copyButton = dialogView.findViewById(R.id.copyButton);
                View closeButton = dialogView.findViewById(R.id.closeButton);
                View shareButton = dialogView.findViewById(R.id.shareButton);

                inviteCodeText.setText(code);

                AlertDialog dialog = new AlertDialog.Builder(requireContext())
                        .setView(dialogView)
                        .create();

                dialog.setOnShowListener(d -> {
                    if (dialog.getWindow() != null) {
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    }
                });

                copyButton.setOnClickListener(v -> {
                    copyCode(code);
                    dialog.dismiss();
                });

                closeButton.setOnClickListener(v -> dialog.dismiss());

                shareButton.setOnClickListener(v -> {
                    shareCode(code);
                    dialog.dismiss();
                });

                dialog.show();
            }
        });
    }

    private void showJoinByCodeDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_join_by_code, null);
        TextInputEditText codeInput = dialogView.findViewById(R.id.codeInput);
        View cancelButton = dialogView.findViewById(R.id.cancelButton);
        View joinButton = dialogView.findViewById(R.id.joinButton);

        if (codeInput != null) {
            codeInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        joinButton.setOnClickListener(v -> {
            String code = codeInput.getText() != null
                    ? codeInput.getText().toString().trim()
                    : "";

            if (code.isEmpty()) {
                Toast.makeText(requireContext(), "Введите код", Toast.LENGTH_SHORT).show();
                return;
            }

            dialog.dismiss();

            chatViewModel.joinChatByCode(currentUser.getId(), code);
            chatViewModel.getJoinResult().observe(getViewLifecycleOwner(), new Observer<Resource<Boolean>>() {
                @Override
                public void onChanged(Resource<Boolean> resource) {
                    if (resource == null) return;
                    if (resource.status == Resource.Status.LOADING) return;

                    chatViewModel.getJoinResult().removeObserver(this);

                    if (resource.status == Resource.Status.SUCCESS) {
                        Toast.makeText(requireContext(), "Вы вошли в группу!", Toast.LENGTH_SHORT).show();
                        loadChats();
                    } else {
                        Toast.makeText(requireContext(), resource.message, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });

        dialog.show();
    }

    private void shareCode(String code) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Присоединяйся к моей группе в SportHelper!\nКод: " + code);
        startActivity(Intent.createChooser(shareIntent, "Поделиться кодом"));
    }

    private void copyCode(String code) {
        ClipboardManager clipboard =
                (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);

        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText("invite_code", code);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(requireContext(), "Код скопирован: " + code, Toast.LENGTH_SHORT).show();
        }
    }
}