package com.example.sporthelper.model;

import java.io.Serializable;

public class Chat implements Serializable {

    private Long    id;
    private String  name;
    private Boolean isGroup;
    private Long    createdBy;
    private String  inviteCode;
    private String  createdAt;
    private String  lastMessage;
    private String  lastMessageTime;

    public Chat() {}

    // ========== GETTERS ==========

    public Long getId()                  { return id; }
    public String getName()              { return name; }
    public Boolean getIsGroup()          { return isGroup; }
    public Long getCreatedBy()           { return createdBy; }
    public String getInviteCode()        { return inviteCode; }
    public String getCreatedAt()         { return createdAt; }
    public String getLastMessage()       { return lastMessage; }
    public String getLastMessageTime()   { return lastMessageTime; }

    // ========== SETTERS ==========

    public void setId(Long id)                             { this.id = id; }
    public void setName(String name)                       { this.name = name; }
    public void setGroup(Boolean group)                    { this.isGroup = group; }
    public void setCreatedBy(Long createdBy)               { this.createdBy = createdBy; }
    public void setInviteCode(String inviteCode)           { this.inviteCode = inviteCode; }
    public void setCreatedAt(String createdAt)             { this.createdAt = createdAt; }
    public void setLastMessage(String lastMessage)         { this.lastMessage = lastMessage; }
    public void setLastMessageTime(String lastMessageTime) { this.lastMessageTime = lastMessageTime; }
}
