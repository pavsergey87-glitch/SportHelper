package com.example.sporthelper.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.sporthelper.R;
import com.example.sporthelper.fragment.ChatListFragment;
import com.example.sporthelper.fragment.NutritionFragment;
import com.example.sporthelper.fragment.WorkoutFragment;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigation;

    private Fragment workoutFragment;
    private Fragment nutritionFragment;
    private Fragment chatListFragment;
    private Fragment activeFragment;

    private SharedPreferencesManager prefsManager;
    private Profile currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefsManager = SharedPreferencesManager.getInstance(this);
        currentUser = prefsManager.getUserProfile();

        if (currentUser == null) {
            navigateToAuth();
            return;
        }

        setContentView(R.layout.activity_main);

        bottomNavigation = findViewById(R.id.bottomNavigation);

        fixBottomNavigation(bottomNavigation);

        if (savedInstanceState == null) {
            workoutFragment = new WorkoutFragment();
            nutritionFragment = new NutritionFragment();
            chatListFragment = new ChatListFragment();
            activeFragment = workoutFragment;

            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.fragmentContainer, chatListFragment, "chat").hide(chatListFragment)
                    .add(R.id.fragmentContainer, nutritionFragment, "nutrition").hide(nutritionFragment)
                    .add(R.id.fragmentContainer, workoutFragment, "workout")
                    .commit();
        } else {
            workoutFragment = getSupportFragmentManager().findFragmentByTag("workout");
            nutritionFragment = getSupportFragmentManager().findFragmentByTag("nutrition");
            chatListFragment = getSupportFragmentManager().findFragmentByTag("chat");

            if (workoutFragment != null && !workoutFragment.isHidden()) {
                activeFragment = workoutFragment;
            } else if (nutritionFragment != null && !nutritionFragment.isHidden()) {
                activeFragment = nutritionFragment;
            } else {
                activeFragment = chatListFragment;
            }
        }

        setupBottomNavigation();
        setupBackPressedHandler();
    }

    private void setupBottomNavigation() {
        bottomNavigation.setSelectedItemId(R.id.nav_workouts);

        bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_workouts) {
                switchFragment(workoutFragment);
                return true;
            } else if (itemId == R.id.nav_nutrition) {
                switchFragment(nutritionFragment);
                return true;
            } else if (itemId == R.id.nav_chat) {
                switchFragment(chatListFragment);
                return true;
            }

            return false;
        });
    }

    private void switchFragment(@NonNull Fragment targetFragment) {
        if (targetFragment == activeFragment) return;

        getSupportFragmentManager()
                .beginTransaction()
                .hide(activeFragment)
                .show(targetFragment)
                .commit();

        activeFragment = targetFragment;
    }

    private void setupBackPressedHandler() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (bottomNavigation.getSelectedItemId() != R.id.nav_workouts) {
                    bottomNavigation.setSelectedItemId(R.id.nav_workouts);
                } else {
                    finish();
                }
            }
        });
    }

    private void navigateToAuth() {
        Intent intent = new Intent(this, AuthActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
    }

    private void fixBottomNavigation(BottomNavigationView navView) {
        if (navView == null) return;

        navView.post(() -> {
            try {
                View menuView = navView.getChildAt(0);
                if (!(menuView instanceof View)) return;

                if (menuView instanceof android.view.ViewGroup) {
                    android.view.ViewGroup menuGroup = (android.view.ViewGroup) menuView;

                    for (int i = 0; i < menuGroup.getChildCount(); i++) {
                        View itemView = menuGroup.getChildAt(i);

                        if (itemView instanceof android.view.ViewGroup) {
                            android.view.ViewGroup itemGroup = (android.view.ViewGroup) itemView;

                            int activeIndicatorId = com.google.android.material.R.id.navigation_bar_item_active_indicator_view;
                            View activeIndicator = itemGroup.findViewById(activeIndicatorId);

                            if (activeIndicator != null) {
                                activeIndicator.setBackground(null);
                                activeIndicator.setAlpha(0f);
                                activeIndicator.setVisibility(View.INVISIBLE);

                                android.view.ViewGroup.LayoutParams lp = activeIndicator.getLayoutParams();
                                if (lp != null) {
                                    lp.width = 0;
                                    lp.height = 0;
                                    activeIndicator.setLayoutParams(lp);
                                }
                            }
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        });
    }
}