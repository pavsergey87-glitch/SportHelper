package com.example.sporthelper.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.model.Chat;
import com.example.sporthelper.util.ChatListTimeUtils;

import java.util.ArrayList;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private List<Chat> chats;
    private final OnChatClickListener listener;

    public interface OnChatClickListener {
        void onChatClick(Chat chat);
    }

    public ChatAdapter(List<Chat> chats, OnChatClickListener listener) {
        this.chats = chats != null ? chats : new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        holder.bind(chats.get(position));
    }

    @Override
    public int getItemCount() {
        return chats != null ? chats.size() : 0;
    }

    public void updateChats(List<Chat> newChats) {
        this.chats = newChats != null ? newChats : new ArrayList<>();
        notifyDataSetChanged();
    }

    class ChatViewHolder extends RecyclerView.ViewHolder {
        private final ImageView chatAvatarSingle;
        private final ImageView chatAvatarGroupBack;
        private final ImageView chatAvatarGroupFront;
        private final TextView chatName;
        private final TextView lastMessage;
        private final TextView lastTime;

        ChatViewHolder(View itemView) {
            super(itemView);
            chatAvatarSingle = itemView.findViewById(R.id.chatAvatarSingle);
            chatAvatarGroupBack = itemView.findViewById(R.id.chatAvatarGroupBack);
            chatAvatarGroupFront = itemView.findViewById(R.id.chatAvatarGroupFront);
            chatName = itemView.findViewById(R.id.chatName);
            lastMessage = itemView.findViewById(R.id.lastMessage);
            lastTime = itemView.findViewById(R.id.lastTime);
        }

        void bind(Chat chat) {
            String name = chat.getName() != null && !chat.getName().trim().isEmpty()
                    ? chat.getName()
                    : "Чат";

            chatName.setText(name);

            boolean isGroup = Boolean.TRUE.equals(chat.getIsGroup());

            if (isGroup) {
                chatAvatarSingle.setVisibility(View.GONE);
                chatAvatarGroupBack.setVisibility(View.VISIBLE);
                chatAvatarGroupFront.setVisibility(View.VISIBLE);
            } else {
                chatAvatarSingle.setVisibility(View.VISIBLE);
                chatAvatarGroupBack.setVisibility(View.GONE);
                chatAvatarGroupFront.setVisibility(View.GONE);
            }

            String preview = chat.getLastMessage() != null && !chat.getLastMessage().trim().isEmpty()
                    ? chat.getLastMessage()
                    : "Нет сообщений";

            lastMessage.setText(preview);

            String formattedTime = "";
            if (chat.getLastMessageTime() != null && !chat.getLastMessageTime().trim().isEmpty()) {
                formattedTime = ChatListTimeUtils.formatChatListTime(chat.getLastMessageTime());
            }
            lastTime.setText(formattedTime);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onChatClick(chat);
                }
            });
        }
    }
}