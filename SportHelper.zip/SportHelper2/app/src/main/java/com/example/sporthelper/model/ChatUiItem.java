package com.example.sporthelper.model;

public class ChatUiItem {

    public static final int TYPE_DATE = 0;
    public static final int TYPE_SENT = 1;
    public static final int TYPE_RECEIVED = 2;

    private final int type;
    private final String dateTitle;
    private final Message message;

    private ChatUiItem(int type, String dateTitle, Message message) {
        this.type = type;
        this.dateTitle = dateTitle;
        this.message = message;
    }

    public static ChatUiItem date(String title) {
        return new ChatUiItem(TYPE_DATE, title, null);
    }

    public static ChatUiItem sent(Message message) {
        return new ChatUiItem(TYPE_SENT, null, message);
    }

    public static ChatUiItem received(Message message) {
        return new ChatUiItem(TYPE_RECEIVED, null, message);
    }

    public int getType() {
        return type;
    }

    public String getDateTitle() {
        return dateTitle;
    }

    public Message getMessage() {
        return message;
    }
}