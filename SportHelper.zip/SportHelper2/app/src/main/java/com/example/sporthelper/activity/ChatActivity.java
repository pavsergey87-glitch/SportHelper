package com.example.sporthelper.activity;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.adapter.MemberAdapter;
import com.example.sporthelper.adapter.MessageAdapter;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Chat;
import com.example.sporthelper.model.Message;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.viewmodel.ChatViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

public class ChatActivity extends AppCompatActivity {

    public static final String EXTRA_CHAT = "chat";
    public static final String EXTRA_CHAT_ID = "chat_id";

    public static final String RESULT_CHAT_ID = "result_chat_id";
    public static final String RESULT_CHAT_NAME = "result_chat_name";

    private ChatViewModel chatViewModel;
    private MessageAdapter messageAdapter;
    private SharedPreferencesManager prefsManager;

    private Chat currentChat;
    private Profile currentUser;
    private Long replyToMessageId = null;

    private MaterialToolbar toolbar;
    private RecyclerView messagesRecyclerView;
    private TextInputEditText messageInput;
    private ImageButton sendButton;
    private LinearLayout replyPreviewContainer;
    private TextView replyPreviewUsername;
    private TextView replyPreviewText;
    private ImageButton cancelReplyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        prefsManager = SharedPreferencesManager.getInstance(this);
        currentUser = prefsManager.getUserProfile();

        if (currentUser == null) {
            Toast.makeText(this, "Ошибка авторизации", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentChat = (Chat) getIntent().getSerializableExtra(EXTRA_CHAT);
        if (currentChat == null) {
            Toast.makeText(this, "Ошибка: чат не найден", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        initViewModel();
        setupToolbar();
        setupRecyclerView();
        setupUI();
        setupObservers();
        loadMessages();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        messagesRecyclerView = findViewById(R.id.messagesRecyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);
        replyPreviewContainer = findViewById(R.id.replyPreviewContainer);
        replyPreviewUsername = findViewById(R.id.replyPreviewUsername);
        replyPreviewText = findViewById(R.id.replyPreviewText);
        cancelReplyButton = findViewById(R.id.cancelReplyButton);
    }

    private void initViewModel() {
        chatViewModel = new ViewModelProvider(this).get(ChatViewModel.class);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(currentChat.getName() != null ? currentChat.getName() : "Чат");
            getSupportActionBar().setSubtitle(
                    Boolean.TRUE.equals(currentChat.getIsGroup()) ? "Групповой чат" : "Личный чат"
            );
        }

        toolbar.post(() -> {
            if (toolbar.getOverflowIcon() != null) {
                toolbar.getOverflowIcon().mutate().setTint(Color.WHITE);
            }
        });

        toolbar.setNavigationOnClickListener(v -> finish());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean isGroup = Boolean.TRUE.equals(currentChat.getIsGroup());
        boolean isCreator = currentChat.getCreatedBy() != null
                && currentUser.getId() != null
                && currentChat.getCreatedBy().equals(currentUser.getId());

        boolean notificationsEnabled = prefsManager.isChatNotificationsEnabled(currentChat.getId());

        MenuItem notificationsItem = menu.findItem(R.id.action_toggle_notifications);
        if (notificationsItem != null) {
            notificationsItem.setVisible(true);
            notificationsItem.setTitle(notificationsEnabled ? "Уведомления: ON" : "Уведомления: OFF");
        }

        MenuItem membersItem = menu.findItem(R.id.action_members);
        if (membersItem != null) {
            membersItem.setVisible(isGroup);
        }

        MenuItem inviteItem = menu.findItem(R.id.action_invite);
        if (inviteItem != null) {
            inviteItem.setVisible(isGroup);
        }

        MenuItem editGroupItem = menu.findItem(R.id.action_edit_group);
        if (editGroupItem != null) {
            editGroupItem.setVisible(isGroup && isCreator);
        }

        MenuItem leaveChatItem = menu.findItem(R.id.action_leave_chat);
        if (leaveChatItem != null) {
            leaveChatItem.setVisible(isGroup && !isCreator);
        }

        MenuItem deleteGroupItem = menu.findItem(R.id.action_delete_group);
        if (deleteGroupItem != null) {
            deleteGroupItem.setVisible(isGroup && isCreator);
        }

        MenuItem reportItem = menu.findItem(R.id.action_report_chat);
        if (reportItem != null) {
            reportItem.setVisible(true);
        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == android.R.id.home) {
            finish();
            return true;
        } else if (itemId == R.id.action_members) {
            showMembers();
            return true;
        } else if (itemId == R.id.action_invite) {
            showInviteCode();
            return true;
        } else if (itemId == R.id.action_toggle_notifications) {
            toggleNotifications();
            return true;
        } else if (itemId == R.id.action_edit_group) {
            showEditGroupDialog();
            return true;
        } else if (itemId == R.id.action_leave_chat) {
            confirmLeaveChat();
            return true;
        } else if (itemId == R.id.action_delete_group) {
            confirmDeleteGroup();
            return true;
        } else if (itemId == R.id.action_report_chat) {
            showReportDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void setupRecyclerView() {
        messageAdapter = new MessageAdapter(currentUser.getId());
        messageAdapter.setOnMessageLongClickListener((message, anchorView, touchX) -> {
            showMessageActions(message);
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        messagesRecyclerView.setLayoutManager(layoutManager);
        messagesRecyclerView.setAdapter(messageAdapter);
    }

    private void setupUI() {
        sendButton.setOnClickListener(v -> sendMessage());
        cancelReplyButton.setOnClickListener(v -> cancelReply());
        replyPreviewContainer.setVisibility(View.GONE);
    }

    private void setupObservers() {
        chatViewModel.getMessages().observe(this, resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case SUCCESS:
                    if (resource.data != null) {
                        messageAdapter.setMessages(resource.data);
                        scrollToBottom();
                    }
                    break;

                case ERROR:
                    Toast.makeText(this, "Ошибка загрузки: " + resource.message, Toast.LENGTH_SHORT).show();
                    break;

                case LOADING:
                    break;
            }
        });

        chatViewModel.getSendResult().observe(this, resource -> {
            if (resource == null) return;

            if (resource.status == Resource.Status.SUCCESS && resource.data != null) {
                messageAdapter.addMessage(resource.data);
                scrollToBottom();
                cancelReply();
            } else if (resource.status == Resource.Status.ERROR) {
                Toast.makeText(this, "Не удалось отправить: " + resource.message, Toast.LENGTH_SHORT).show();
            }
        });

        chatViewModel.getDeleteResult().observe(this, resource -> {
            if (resource == null) return;
            if (resource.status == Resource.Status.SUCCESS) {
                Toast.makeText(this, "Сообщение удалено", Toast.LENGTH_SHORT).show();
                loadMessages();
            }
        });

        chatViewModel.getEditResult().observe(this, resource -> {
            if (resource == null) return;
            if (resource.status == Resource.Status.SUCCESS) {
                loadMessages();
            }
        });

        chatViewModel.getMembersResult().observe(this, resource -> {
            if (resource == null) return;
            if (resource.status == Resource.Status.SUCCESS && resource.data != null) {
                showMembersDialog(resource.data);
            }
        });

        chatViewModel.getInviteCodeResult().observe(this, resource -> {
            if (resource == null) return;
            if (resource.status == Resource.Status.SUCCESS && resource.data != null) {
                showInviteCodeDialog(resource.data);
            }
        });

        chatViewModel.getUpdateGroupResult().observe(this, resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case LOADING:
                    break;

                case SUCCESS:
                    Toast.makeText(this, "Название группы обновлено", Toast.LENGTH_SHORT).show();
                    applyUpdatedChatName(currentChat.getName());
                    break;

                case ERROR:
                    Toast.makeText(this, "Ошибка: " + resource.message, Toast.LENGTH_LONG).show();
                    break;
            }
        });

        chatViewModel.getLeaveChatResult().observe(this, resource -> {
            if (resource == null) return;

            if (resource.status == Resource.Status.SUCCESS) {
                Toast.makeText(this, "Вы покинули группу", Toast.LENGTH_SHORT).show();
                finish();
            } else if (resource.status == Resource.Status.ERROR) {
                Toast.makeText(this, "Ошибка: " + resource.message, Toast.LENGTH_SHORT).show();
            }
        });

        chatViewModel.getDeleteGroupResult().observe(this, resource -> {
            if (resource == null) return;

            if (resource.status == Resource.Status.SUCCESS) {
                Toast.makeText(this, "Группа удалена", Toast.LENGTH_SHORT).show();
                finish();
            } else if (resource.status == Resource.Status.ERROR) {
                Toast.makeText(this, "Ошибка: " + resource.message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void applyUpdatedChatName(String newName) {
        if (newName == null || newName.trim().isEmpty()) return;

        currentChat.setName(newName);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(newName);
        }

        Intent resultIntent = new Intent();
        resultIntent.putExtra(RESULT_CHAT_ID, currentChat.getId());
        resultIntent.putExtra(RESULT_CHAT_NAME, newName);
        setResult(Activity.RESULT_OK, resultIntent);

        invalidateOptionsMenu();
    }

    private void loadMessages() {
        chatViewModel.loadMessages(currentChat.getId());
    }

    private void sendMessage() {
        String text = messageInput.getText() != null
                ? messageInput.getText().toString().trim()
                : "";

        if (text.isEmpty()) return;

        chatViewModel.sendMessage(
                currentChat.getId(),
                currentUser.getId(),
                text,
                replyToMessageId
        );

        messageInput.setText("");
    }

    private void showMessageActions(Message message) {
        boolean isMyMessage = message.getSenderId() != null
                && message.getSenderId().equals(currentUser.getId());

        String[] actions = isMyMessage
                ? new String[]{"Ответить", "Редактировать", "Удалить", "Копировать"}
                : new String[]{"Ответить", "Копировать"};

        new AlertDialog.Builder(this)
                .setTitle("Действие")
                .setItems(actions, (dialog, which) -> {
                    if (isMyMessage) {
                        switch (which) {
                            case 0:
                                startReply(message);
                                break;
                            case 1:
                                showEditDialog(message);
                                break;
                            case 2:
                                confirmDelete(message);
                                break;
                            case 3:
                                copyMessage(message);
                                break;
                        }
                    } else {
                        switch (which) {
                            case 0:
                                startReply(message);
                                break;
                            case 1:
                                copyMessage(message);
                                break;
                        }
                    }
                })
                .show();
    }

    private void startReply(Message message) {
        replyToMessageId = message.getId();
        replyPreviewContainer.setVisibility(View.VISIBLE);
        replyPreviewUsername.setText(
                message.getSenderUsername() != null ? message.getSenderUsername() : "Пользователь"
        );

        String preview = message.getContent() != null ? message.getContent() : "";
        if (preview.length() > 60) {
            preview = preview.substring(0, 60) + "...";
        }
        replyPreviewText.setText(preview);
    }

    private void cancelReply() {
        replyToMessageId = null;
        replyPreviewContainer.setVisibility(View.GONE);
        replyPreviewUsername.setText("");
        replyPreviewText.setText("");
    }

    private void showEditDialog(Message message) {
        EditText input = new EditText(this);
        input.setText(message.getContent());
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this)
                .setTitle("Редактировать сообщение")
                .setView(input)
                .setPositiveButton("Сохранить", (dialog, which) -> {
                    String newText = input.getText().toString().trim();
                    if (!newText.isEmpty()) {
                        chatViewModel.editMessage(message.getId(), newText);
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void confirmDelete(Message message) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить сообщение?")
                .setMessage("Это действие нельзя отменить")
                .setPositiveButton("Удалить", (dialog, which) ->
                        chatViewModel.deleteMessage(message.getId()))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void copyMessage(Message message) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("message", message.getContent());

        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMembers() {
        chatViewModel.loadChatMembers(currentChat.getId());
    }

    private void showInviteCode() {
        chatViewModel.getInviteCode(currentChat.getId());
    }

    private void toggleNotifications() {
        boolean current = prefsManager.isChatNotificationsEnabled(currentChat.getId());
        boolean updated = !current;
        prefsManager.setChatNotificationsEnabled(currentChat.getId(), updated);

        invalidateOptionsMenu();

        Toast.makeText(
                this,
                updated ? "Уведомления включены" : "Уведомления выключены",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void showEditGroupDialog() {
        if (!Boolean.TRUE.equals(currentChat.getIsGroup())) return;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_group, null);
        EditText groupNameInput = dialogView.findViewById(R.id.groupNameInput);
        View cancelButton = dialogView.findViewById(R.id.cancelButton);
        View saveButton = dialogView.findViewById(R.id.saveButton);

        if (currentChat.getName() != null) {
            groupNameInput.setText(currentChat.getName());
            groupNameInput.setSelection(groupNameInput.getText().length());
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String newName = groupNameInput.getText().toString().trim();
            if (newName.isEmpty()) {
                Toast.makeText(this, "Введите название группы", Toast.LENGTH_SHORT).show();
                return;
            }

            currentChat.setName(newName);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle(newName);
            }

            chatViewModel.updateGroupName(currentChat.getId(), newName);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void confirmLeaveChat() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_confirm_chat_action, null);
        TextView title = dialogView.findViewById(R.id.confirmTitle);
        TextView message = dialogView.findViewById(R.id.confirmMessage);
        MaterialButton cancelButton = dialogView.findViewById(R.id.confirmCancelButton);
        MaterialButton okButton = dialogView.findViewById(R.id.confirmOkButton);

        title.setText("Покинуть группу?");
        message.setText("Вы больше не будете участником этой группы.");
        okButton.setText("Покинуть");

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());
        okButton.setOnClickListener(v -> {
            chatViewModel.leaveChat(currentChat.getId(), currentUser.getId());
            dialog.dismiss();
        });

        dialog.show();
    }

    private void confirmDeleteGroup() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_confirm_chat_action, null);
        TextView title = dialogView.findViewById(R.id.confirmTitle);
        TextView message = dialogView.findViewById(R.id.confirmMessage);
        MaterialButton cancelButton = dialogView.findViewById(R.id.confirmCancelButton);
        MaterialButton okButton = dialogView.findViewById(R.id.confirmOkButton);

        title.setText("Удалить группу?");
        message.setText("Группа будет удалена полностью. Это действие нельзя отменить.");
        okButton.setText("Удалить");

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());
        okButton.setOnClickListener(v -> {
            chatViewModel.deleteGroup(currentChat.getId());
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showReportDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_report_chat, null);
        RadioGroup group = dialogView.findViewById(R.id.reportReasonsGroup);
        View cancelButton = dialogView.findViewById(R.id.cancelReportButton);
        View sendButton = dialogView.findViewById(R.id.sendReportButton);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        sendButton.setOnClickListener(v -> {
            int checkedId = group.getCheckedRadioButtonId();
            if (checkedId == -1) {
                Toast.makeText(this, "Выберите причину", Toast.LENGTH_SHORT).show();
                return;
            }

            String reason;
            if (checkedId == R.id.reasonSpam) {
                reason = "Спам";
            } else if (checkedId == R.id.reasonInsult) {
                reason = "Оскорбления";
            } else if (checkedId == R.id.reasonFraud) {
                reason = "Мошенничество";
            } else {
                reason = "Другое";
            }

            Toast.makeText(this, "Жалоба отправлена: " + reason, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showMembersDialog(List<String> members) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_chat_members, null);
        TextView membersTitle = dialogView.findViewById(R.id.membersTitle);
        RecyclerView membersRecyclerView = dialogView.findViewById(R.id.membersRecyclerView);
        View closeButton = dialogView.findViewById(R.id.closeMembersButton);

        membersTitle.setText("Участники (" + members.size() + ")");

        MemberAdapter adapter = new MemberAdapter();
        adapter.setMembers(members);

        membersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        membersRecyclerView.setAdapter(adapter);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        closeButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void showInviteCodeDialog(String code) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_invite_code, null);
        TextView inviteCodeText = dialogView.findViewById(R.id.inviteCodeText);
        View closeButton = dialogView.findViewById(R.id.closeInviteButton);
        View copyButton = dialogView.findViewById(R.id.copyInviteButton);

        inviteCodeText.setText(code);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        closeButton.setOnClickListener(v -> dialog.dismiss());

        copyButton.setOnClickListener(v -> {
            ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("invite_code", code);
            if (clipboard != null) {
                clipboard.setPrimaryClip(clip);
            }
            Toast.makeText(this, "Код скопирован", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void scrollToBottom() {
        int count = messageAdapter.getItemCount();
        if (count > 0) {
            messagesRecyclerView.scrollToPosition(count - 1);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (prefsManager != null && currentChat != null && currentChat.getId() != null) {
            prefsManager.setOpenChatId(currentChat.getId());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (prefsManager != null) {
            Long openChatId = prefsManager.getOpenChatId();
            if (currentChat != null && currentChat.getId() != null
                    && openChatId != null
                    && openChatId.equals(currentChat.getId())) {
                prefsManager.clearOpenChatId();
            }
        }
    }
}