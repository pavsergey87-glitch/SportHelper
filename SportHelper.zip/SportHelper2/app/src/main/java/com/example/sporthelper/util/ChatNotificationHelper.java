package com.example.sporthelper.util;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.sporthelper.R;
import com.example.sporthelper.activity.ChatActivity;
import com.example.sporthelper.model.Chat;

public class ChatNotificationHelper {

    public static final String CHANNEL_ID = "chat_messages_channel";
    public static final String CHANNEL_NAME = "Сообщения чата";
    public static final String CHANNEL_DESCRIPTION = "Уведомления о новых сообщениях";

    private ChatNotificationHelper() {
    }

    public static void createNotificationChannel(Context context) {
        if (context == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            if (notificationManager == null) return;

            NotificationChannel existingChannel =
                    notificationManager.getNotificationChannel(CHANNEL_ID);

            if (existingChannel != null) return;

            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(CHANNEL_DESCRIPTION);
            channel.enableLights(true);
            channel.enableVibration(true);

            notificationManager.createNotificationChannel(channel);
        }
    }

    public static boolean hasNotificationPermission(Context context) {
        if (context == null) return false;

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return true;
        }

        return ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    public static void showChatNotification(
            Context context,
            Chat chat,
            String title,
            String messageText
    ) {
        if (context == null || chat == null || chat.getId() == null) {
            return;
        }

        createNotificationChannel(context);

        if (!hasNotificationPermission(context)) {
            return;
        }

        String safeTitle = (title != null && !title.trim().isEmpty())
                ? title.trim()
                : "Новое сообщение";

        String safeMessage = (messageText != null && !messageText.trim().isEmpty())
                ? messageText.trim()
                : "Открой чат, чтобы посмотреть сообщение";

        Intent openChatIntent = new Intent(context, ChatActivity.class);
        openChatIntent.putExtra(ChatActivity.EXTRA_CHAT, chat);
        openChatIntent.putExtra(ChatActivity.EXTRA_CHAT_ID, chat.getId());
        openChatIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                chat.getId().intValue(),
                openChatIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_chat)
                .setContentTitle(safeTitle)
                .setContentText(safeMessage)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(safeMessage))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE);

        try {
            NotificationManagerCompat.from(context)
                    .notify(chat.getId().intValue(), builder.build());
        } catch (SecurityException ignored) {
        }
    }

    public static void cancelChatNotification(Context context, Long chatId) {
        if (context == null || chatId == null) return;

        NotificationManagerCompat.from(context).cancel(chatId.intValue());
    }

    public static void cancelAllChatNotifications(Context context) {
        if (context == null) return;

        NotificationManagerCompat.from(context).cancelAll();
    }
}