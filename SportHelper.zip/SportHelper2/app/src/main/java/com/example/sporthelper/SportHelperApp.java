package com.example.sporthelper;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

public class SportHelperApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        // Применяем тему при запуске приложения
        SharedPreferences prefs = getSharedPreferences("SportHelperPrefs", MODE_PRIVATE);
        boolean isDark = prefs.getBoolean("dark_theme", false);
        AppCompatDelegate.setDefaultNightMode(
                isDark
                        ? AppCompatDelegate.MODE_NIGHT_YES
                        : AppCompatDelegate.MODE_NIGHT_NO
        );
    }
}
