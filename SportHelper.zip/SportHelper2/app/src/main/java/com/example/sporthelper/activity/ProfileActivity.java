package com.example.sporthelper.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.sporthelper.R;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.viewmodel.ProfileViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class ProfileActivity extends AppCompatActivity {

    private Profile currentUser;
    private SharedPreferencesManager prefsManager;
    private ProfileViewModel profileViewModel;

    private TextView usernameText;
    private TextView emailText;
    private TextView fitnessLevelText;
    private TextView weightText;
    private TextView heightText;
    private MaterialButton editProfileButton;
    private MaterialButton logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        prefsManager = SharedPreferencesManager.getInstance(this);
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        initViews();
        loadUserData();
        setupObservers();
        setupUI();
    }

    private void initViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            toolbar.setNavigationOnClickListener(v -> {
                onBackPressed();
                overridePendingTransition(0, 0);
            });
        }

        usernameText = findViewById(R.id.usernameText);
        emailText = findViewById(R.id.emailText);
        fitnessLevelText = findViewById(R.id.fitnessLevelText);
        weightText = findViewById(R.id.weightText);
        heightText = findViewById(R.id.heightText);
        editProfileButton = findViewById(R.id.editProfileButton);
        logoutButton = findViewById(R.id.logoutButton);
    }

    private void loadUserData() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("profile")) {
            currentUser = (Profile) intent.getSerializableExtra("profile");
        }

        if (currentUser == null) {
            currentUser = prefsManager.getUserProfile();
        }

        if (currentUser == null) {
            Toast.makeText(this, "Профиль не найден", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        updateUI();
    }

    private void setupObservers() {
        profileViewModel.getUpdateProfileResult().observe(this, resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case LOADING:
                    Toast.makeText(this, "Сохранение...", Toast.LENGTH_SHORT).show();
                    break;

                case SUCCESS:
                    if (resource.data != null) {
                        currentUser = resource.data;
                        prefsManager.saveUserProfile(currentUser);
                        updateUI();
                        Toast.makeText(this, "Профиль обновлён", Toast.LENGTH_SHORT).show();
                    }
                    break;

                case ERROR:
                    Toast.makeText(
                            this,
                            resource.message != null ? resource.message : "Ошибка обновления профиля",
                            Toast.LENGTH_LONG
                    ).show();
                    break;
            }
        });
    }

    private void updateUI() {
        if (usernameText != null) {
            usernameText.setText(currentUser.getUsername() != null ? currentUser.getUsername() : "—");
        }

        if (emailText != null) {
            emailText.setText(currentUser.getEmail() != null ? currentUser.getEmail() : "—");
        }

        if (fitnessLevelText != null) {
            fitnessLevelText.setText(getFitnessLevelDisplayName(currentUser.getFitnessLevel()));
        }

        if (weightText != null) {
            weightText.setText(currentUser.getWeight() != null ? trimDouble(currentUser.getWeight()) + " кг" : "—");
        }

        if (heightText != null) {
            heightText.setText(currentUser.getHeight() != null ? trimDouble(currentUser.getHeight()) + " см" : "—");
        }
    }

    private void setupUI() {
        if (editProfileButton != null) {
            editProfileButton.setOnClickListener(v -> showEditProfileDialog());
        }

        if (logoutButton != null) {
            logoutButton.setOnClickListener(v -> showLogoutConfirmation());
        }
    }

    private void showEditProfileDialog() {
        android.view.View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_profile, null);

        TextInputEditText editUsernameInput = dialogView.findViewById(R.id.editUsernameInput);
        TextInputEditText editFullNameInput = dialogView.findViewById(R.id.editFullNameInput);
        TextInputEditText editWeightInput = dialogView.findViewById(R.id.editWeightInput);
        TextInputEditText editHeightInput = dialogView.findViewById(R.id.editHeightInput);
        AutoCompleteTextView editFitnessLevelInput = dialogView.findViewById(R.id.editFitnessLevelInput);
        MaterialButton cancelButton = dialogView.findViewById(R.id.cancelButton);
        MaterialButton saveButton = dialogView.findViewById(R.id.saveButton);

        String[] levels = {"Начинающий", "Средний", "Продвинутый"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                levels
        );
        editFitnessLevelInput.setAdapter(adapter);

        if (currentUser.getUsername() != null) {
            editUsernameInput.setText(currentUser.getUsername());
        }

        if (currentUser.getFullName() != null) {
            editFullNameInput.setText(currentUser.getFullName());
        }

        if (currentUser.getWeight() != null) {
            editWeightInput.setText(trimDouble(currentUser.getWeight()));
        }

        if (currentUser.getHeight() != null) {
            editHeightInput.setText(trimDouble(currentUser.getHeight()));
        }

        editFitnessLevelInput.setText(
                getFitnessLevelDisplayName(currentUser.getFitnessLevel()),
                false
        );

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String username = textOf(editUsernameInput);
            String fullName = textOf(editFullNameInput);
            String weightText = textOf(editWeightInput);
            String heightText = textOf(editHeightInput);
            String fitnessLevelDisplay = editFitnessLevelInput.getText() != null
                    ? editFitnessLevelInput.getText().toString().trim()
                    : "";

            if (username.isEmpty()) {
                Toast.makeText(this, "Введите имя пользователя", Toast.LENGTH_SHORT).show();
                return;
            }

            if (username.length() < 3) {
                Toast.makeText(this, "Имя пользователя минимум 3 символа", Toast.LENGTH_SHORT).show();
                return;
            }

            if (fullName.isEmpty()) {
                Toast.makeText(this, "Введите полное имя", Toast.LENGTH_SHORT).show();
                return;
            }

            Double weight;
            Double height;

            try {
                weight = weightText.isEmpty() ? null : Double.parseDouble(weightText);
                height = heightText.isEmpty() ? null : Double.parseDouble(heightText);
            } catch (Exception e) {
                Toast.makeText(this, "Вес и рост должны быть числами", Toast.LENGTH_SHORT).show();
                return;
            }

            String fitnessLevelDb = convertFitnessLevelToDb(fitnessLevelDisplay);

            if (fitnessLevelDb == null) {
                Toast.makeText(this, "Выберите уровень подготовки", Toast.LENGTH_SHORT).show();
                return;
            }

            if (currentUser.getId() == null) {
                Toast.makeText(this, "ID профиля не найден", Toast.LENGTH_SHORT).show();
                return;
            }

            profileViewModel.updateProfile(
                    currentUser.getId(),
                    username,
                    fullName,
                    weight,
                    height,
                    fitnessLevelDb
            );

            dialog.dismiss();
        });

        dialog.show();
    }

    private String textOf(TextInputEditText editText) {
        return editText.getText() != null ? editText.getText().toString().trim() : "";
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Выход")
                .setMessage("Вы уверены, что хотите выйти из аккаунта?")
                .setPositiveButton("Выйти", (dialog, which) -> logout())
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void logout() {
        prefsManager.logout();
        Toast.makeText(this, "Вы вышли из аккаунта", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, AuthActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
    }

    private String getFitnessLevelDisplayName(String level) {
        if (level == null) return "—";

        switch (level) {
            case "beginner":
                return "Начинающий";
            case "intermediate":
                return "Средний";
            case "advanced":
                return "Продвинутый";
            default:
                return level;
        }
    }

    private String convertFitnessLevelToDb(String displayLevel) {
        switch (displayLevel) {
            case "Начинающий":
                return "beginner";
            case "Средний":
                return "intermediate";
            case "Продвинутый":
                return "advanced";
            default:
                return null;
        }
    }

    private String trimDouble(Double value) {
        if (value == null) return "";
        if (value == Math.floor(value)) {
            return String.valueOf(value.intValue());
        }
        return String.valueOf(value);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(0, 0);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}