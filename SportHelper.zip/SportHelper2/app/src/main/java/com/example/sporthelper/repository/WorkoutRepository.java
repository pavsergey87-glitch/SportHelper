package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Resource;
import com.example.sporthelper.model.Workout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Request;

public class WorkoutRepository extends BaseRepository {

    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Gson gson = new Gson();

    public WorkoutRepository(Context context) {
        super(context);
    }

    public LiveData<Resource<List<Workout>>> getWorkoutsByUserAndDate(Long userId, String workoutDate) {
        MutableLiveData<Resource<List<Workout>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "workout_logs?user_id=eq." + userId
                        + "&workout_date=eq." + workoutDate
                        + "&select=*"
                        + "&order=id.desc";

                Request request = createSupabaseRequest(endpoint, "GET", null);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                List<Workout> workouts = new ArrayList<>();

                if (jsonArray != null) {
                    for (int i = 0; i < jsonArray.size(); i++) {
                        JsonObject workoutObj = jsonArray.get(i).getAsJsonObject();
                        workouts.add(parseWorkout(workoutObj));
                    }
                }

                result.postValue(Resource.success(workouts));

            } catch (Exception e) {
                Log.e("WorkoutRepository", "Ошибка загрузки тренировок: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка загрузки: " + e.getMessage(), new ArrayList<>()));
            }
        });

        return result;
    }

    public LiveData<Resource<Workout>> addWorkout(
            Long userId,
            String workoutName,
            String workoutDate,
            Integer durationMinutes,
            Integer caloriesBurned,
            String notes
    ) {
        MutableLiveData<Resource<Workout>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                JsonObject body = new JsonObject();
                body.addProperty("user_id", userId);
                body.addProperty("workout_name", workoutName);
                body.addProperty("workout_date", workoutDate);
                body.addProperty("duration_minutes", durationMinutes);
                body.addProperty("calories_burned", caloriesBurned);

                if (notes != null && !notes.trim().isEmpty()) {
                    body.addProperty("notes", notes.trim());
                } else {
                    body.add("notes", null);
                }

                Request request = createSupabaseRequest("workout_logs?select=*", "POST", body);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                if (jsonArray != null && jsonArray.size() > 0) {
                    Workout workout = parseWorkout(jsonArray.get(0).getAsJsonObject());
                    result.postValue(Resource.success(workout));
                } else {
                    result.postValue(Resource.error("Не удалось добавить тренировку", null));
                }

            } catch (Exception e) {
                Log.e("WorkoutRepository", "Ошибка добавления тренировки: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка добавления: " + e.getMessage(), null));
            }
        });

        return result;
    }

    private Workout parseWorkout(JsonObject workoutObj) {
        Workout workout = new Workout();

        if (workoutObj.has("id") && !workoutObj.get("id").isJsonNull()) {
            workout.setId(workoutObj.get("id").getAsLong());
        }

        if (workoutObj.has("user_id") && !workoutObj.get("user_id").isJsonNull()) {
            workout.setUserId(workoutObj.get("user_id").getAsLong());
        }

        if (workoutObj.has("workout_name") && !workoutObj.get("workout_name").isJsonNull()) {
            workout.setWorkoutName(workoutObj.get("workout_name").getAsString());
        }

        if (workoutObj.has("workout_date") && !workoutObj.get("workout_date").isJsonNull()) {
            workout.setWorkoutDate(workoutObj.get("workout_date").getAsString());
        }

        if (workoutObj.has("duration_minutes") && !workoutObj.get("duration_minutes").isJsonNull()) {
            workout.setDurationMinutes(workoutObj.get("duration_minutes").getAsInt());
        }

        if (workoutObj.has("calories_burned") && !workoutObj.get("calories_burned").isJsonNull()) {
            workout.setCaloriesBurned(workoutObj.get("calories_burned").getAsInt());
        }

        if (workoutObj.has("notes") && !workoutObj.get("notes").isJsonNull()) {
            workout.setNotes(workoutObj.get("notes").getAsString());
        }

        return workout;
    }
}