package com.example.sporthelper.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.example.sporthelper.R;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.util.ChatNotificationHelper;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferencesManager prefsManager;
    private SharedPreferences settingsPrefs;

    private SwitchCompat notificationsSwitch;
    private SwitchCompat darkThemeSwitch;
    private SwitchCompat syncSwitch;
    private Button aboutButton;
    private Button privacyButton;

    private final ActivityResultLauncher<String> notificationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    saveSetting("chat_notifications_global", true);
                    if (notificationsSwitch != null) {
                        notificationsSwitch.setChecked(true);
                    }
                    ChatNotificationHelper.createNotificationChannel(this);
                    Toast.makeText(this, "Уведомления чата включены", Toast.LENGTH_SHORT).show();
                } else {
                    saveSetting("chat_notifications_global", false);
                    if (notificationsSwitch != null) {
                        notificationsSwitch.setChecked(false);
                    }
                    Toast.makeText(this, "Разрешение на уведомления не выдано", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefsManager = SharedPreferencesManager.getInstance(this);
        settingsPrefs = prefsManager.getSharedPreferences();

        initViews();
        setupUI();
    }

    private void initViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Настройки");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        notificationsSwitch = findViewById(R.id.notificationsSwitch);
        darkThemeSwitch = findViewById(R.id.darkThemeSwitch);
        syncSwitch = findViewById(R.id.syncSwitch);
        aboutButton = findViewById(R.id.aboutButton);
        privacyButton = findViewById(R.id.privacyButton);
    }

    private void setupUI() {
        loadSettings();

        notificationsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!buttonView.isPressed()) return;

            if (isChecked) {
                enableChatNotifications();
            } else {
                saveSetting("chat_notifications_global", false);
                Toast.makeText(this, "Уведомления чата выключены", Toast.LENGTH_SHORT).show();
            }
        });

        darkThemeSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            saveSetting("dark_theme", isChecked);
            AppCompatDelegate.setDefaultNightMode(
                    isChecked
                            ? AppCompatDelegate.MODE_NIGHT_YES
                            : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        syncSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            saveSetting("auto_sync", isChecked);
            Toast.makeText(
                    this,
                    isChecked ? "Авто-синхронизация включена" : "Авто-синхронизация выключена",
                    Toast.LENGTH_SHORT
            ).show();
        });

        aboutButton.setOnClickListener(v -> showAboutDialog());

        privacyButton.setOnClickListener(v ->
                Toast.makeText(this, "Политика конфиденциальности", Toast.LENGTH_SHORT).show()
        );
    }

    private void loadSettings() {
        notificationsSwitch.setChecked(settingsPrefs.getBoolean("chat_notifications_global", true));
        darkThemeSwitch.setChecked(settingsPrefs.getBoolean("dark_theme", false));
        syncSwitch.setChecked(settingsPrefs.getBoolean("auto_sync", true));
    }

    private void enableChatNotifications() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            saveSetting("chat_notifications_global", true);
            ChatNotificationHelper.createNotificationChannel(this);
            Toast.makeText(this, "Уведомления чата включены", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) {
            saveSetting("chat_notifications_global", true);
            ChatNotificationHelper.createNotificationChannel(this);
            Toast.makeText(this, "Уведомления чата включены", Toast.LENGTH_SHORT).show();
        } else {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    private void saveSetting(String key, boolean value) {
        settingsPrefs.edit().putBoolean(key, value).apply();
    }

    private void showAboutDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_about_app, null);
        TextView aboutVersionText = dialogView.findViewById(R.id.aboutVersionText);
        TextView aboutDescriptionText = dialogView.findViewById(R.id.aboutDescriptionText);
        View aboutOkButton = dialogView.findViewById(R.id.aboutOkButton);

        aboutVersionText.setText("SportHelper v1.0");
        aboutDescriptionText.setText("Приложение для трекинга тренировок и питания.");

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(
                        new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
                );
            }
        });

        aboutOkButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}