package com.example.sporthelper.adapter;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.model.Message;
import com.example.sporthelper.util.MessageDateDividerUtils;
import com.example.sporthelper.util.MessageTimeUtils;

import java.util.ArrayList;
import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_DATE = 0;
    private static final int VIEW_TYPE_SENT = 1;
    private static final int VIEW_TYPE_RECEIVED = 2;

    private final List<Object> displayItems = new ArrayList<>();
    private final Long currentUserId;
    private OnMessageLongClickListener longClickListener;

    public interface OnMessageLongClickListener {
        void onMessageLongClick(Message message, int rawX, int rawY);
    }

    public MessageAdapter(Long currentUserId) {
        this.currentUserId = currentUserId;
    }

    public void setOnMessageLongClickListener(OnMessageLongClickListener listener) {
        this.longClickListener = listener;
    }

    public void setMessages(List<Message> newMessages) {
        displayItems.clear();

        List<Message> safeMessages = newMessages != null ? newMessages : new ArrayList<>();
        String lastDayKey = null;

        for (Message message : safeMessages) {
            String dayKey = MessageDateDividerUtils.buildDayKey(message.getCreatedAt());

            if (lastDayKey == null || !lastDayKey.equals(dayKey)) {
                displayItems.add(MessageDateDividerUtils.formatDayLabel(message.getCreatedAt()));
                lastDayKey = dayKey;
            }

            displayItems.add(message);
        }

        notifyDataSetChanged();
    }

    public void addMessage(Message message) {
        if (message == null) {
            return;
        }

        if (displayItems.isEmpty()) {
            displayItems.add(MessageDateDividerUtils.formatDayLabel(message.getCreatedAt()));
            displayItems.add(message);
            notifyDataSetChanged();
            return;
        }

        Message lastMessage = null;
        for (int i = displayItems.size() - 1; i >= 0; i--) {
            Object item = displayItems.get(i);
            if (item instanceof Message) {
                lastMessage = (Message) item;
                break;
            }
        }

        if (lastMessage == null || !MessageDateDividerUtils.isSameDay(lastMessage.getCreatedAt(), message.getCreatedAt())) {
            displayItems.add(MessageDateDividerUtils.formatDayLabel(message.getCreatedAt()));
        }

        displayItems.add(message);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        Object item = displayItems.get(position);

        if (item instanceof String) {
            return VIEW_TYPE_DATE;
        }

        Message message = (Message) item;
        return (message.getSenderId() != null && message.getSenderId().equals(currentUserId))
                ? VIEW_TYPE_SENT
                : VIEW_TYPE_RECEIVED;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        if (viewType == VIEW_TYPE_DATE) {
            View view = inflater.inflate(R.layout.item_chat_date_header, parent, false);
            return new DateViewHolder(view);
        } else if (viewType == VIEW_TYPE_SENT) {
            View view = inflater.inflate(R.layout.item_message_sent, parent, false);
            return new SentViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_message_received, parent, false);
            return new ReceivedViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Object item = displayItems.get(position);

        if (holder instanceof DateViewHolder) {
            ((DateViewHolder) holder).bind((String) item);
            return;
        }

        Message message = (Message) item;

        if (holder instanceof SentViewHolder) {
            ((SentViewHolder) holder).bind(message);
        } else if (holder instanceof ReceivedViewHolder) {
            ((ReceivedViewHolder) holder).bind(message);
        }

        final int[] touchPoint = new int[2];

        holder.itemView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                touchPoint[0] = (int) event.getRawX();
                touchPoint[1] = (int) event.getRawY();
            }
            return false;
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onMessageLongClick(message, touchPoint[0], touchPoint[1]);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return displayItems.size();
    }

    static class DateViewHolder extends RecyclerView.ViewHolder {
        private final TextView dateText;

        DateViewHolder(@NonNull View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
        }

        void bind(String label) {
            dateText.setText(label);
        }
    }

    class SentViewHolder extends RecyclerView.ViewHolder {
        private final TextView messageText;
        private final TextView messageTime;
        private final LinearLayout replyContainer;
        private final TextView replyUsername;
        private final TextView replyText;

        SentViewHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.messageText);
            messageTime = itemView.findViewById(R.id.messageTime);
            replyContainer = itemView.findViewById(R.id.replyContainer);
            replyUsername = itemView.findViewById(R.id.replyUsername);
            replyText = itemView.findViewById(R.id.replyText);
        }

        void bind(Message message) {
            messageText.setText(message.getContent() != null ? message.getContent() : "");
            messageTime.setText(MessageTimeUtils.formatMessageTime(message.getCreatedAt()));

            if (message.getReplyToId() != null && message.getReplyToText() != null) {
                replyContainer.setVisibility(View.VISIBLE);
                replyUsername.setText(message.getReplyToUsername() != null
                        ? message.getReplyToUsername()
                        : "");
                replyText.setText(message.getReplyToText());
            } else {
                replyContainer.setVisibility(View.GONE);
            }
        }
    }

    class ReceivedViewHolder extends RecyclerView.ViewHolder {
        private final TextView messageText;
        private final TextView messageTime;
        private final TextView senderName;
        private final LinearLayout replyContainer;
        private final TextView replyUsername;
        private final TextView replyText;

        ReceivedViewHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.messageText);
            messageTime = itemView.findViewById(R.id.messageTime);
            senderName = itemView.findViewById(R.id.senderName);
            replyContainer = itemView.findViewById(R.id.replyContainer);
            replyUsername = itemView.findViewById(R.id.replyUsername);
            replyText = itemView.findViewById(R.id.replyText);
        }

        void bind(Message message) {
            messageText.setText(message.getContent() != null ? message.getContent() : "");
            messageTime.setText(MessageTimeUtils.formatMessageTime(message.getCreatedAt()));
            senderName.setText(message.getSenderUsername() != null
                    ? message.getSenderUsername()
                    : "");

            if (message.getReplyToId() != null && message.getReplyToText() != null) {
                replyContainer.setVisibility(View.VISIBLE);
                replyUsername.setText(message.getReplyToUsername() != null
                        ? message.getReplyToUsername()
                        : "");
                replyText.setText(message.getReplyToText());
            } else {
                replyContainer.setVisibility(View.GONE);
            }
        }
    }
}