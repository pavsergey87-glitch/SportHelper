package com.example.sporthelper.activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.example.sporthelper.R;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.viewmodel.AuthViewModel;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AuthActivity extends AppCompatActivity {
    private AuthViewModel authViewModel;
    private boolean isSignUpMode = false;

    private LinearLayout signInForm, signUpForm;
    private TextView signInTabButton, signUpTabButton;
    private EditText emailEditText, passwordEditText;
    private Button signInButton;
    private EditText signUpFullNameEditText, signUpUsernameEditText, signUpEmailEditText, signUpPasswordEditText;
    private RadioGroup genderRadioGroup;
    private Button birthDateButton, signUpButton;
    private TextView selectedDateText, weightValueText, heightValueText;
    private SeekBar weightSeekBar, heightSeekBar;
    private Spinner fitnessLevelSpinner;
    private ProgressBar progressBar;
    private Calendar birthDateCalendar;
    private SimpleDateFormat dateFormatter;

    private final List<String> allowedEmailDomains = Arrays.asList(
            "gmail.com", "yandex.ru", "mail.ru", "rambler.ru",
            "outlook.com", "hotmail.com", "yahoo.com", "icloud.com",
            "protonmail.com", "aol.com"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        SharedPreferencesManager prefsManager = SharedPreferencesManager.getInstance(this);
        if (prefsManager.isLoggedIn() && prefsManager.getUserProfile() != null) {
            Log.d("AuthActivity", "Пользователь уже залогинен, переход на MainActivity");
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            overridePendingTransition(0, 0);
            finish();
            return;
        }

        try {
            Log.d("AuthActivity", "onCreate");
            setContentView(R.layout.activity_auth);
            initViews();
            initViewModel();
            setupUI();
            updateUI();
        } catch (Exception e) {
            Log.e("AuthActivity", "onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Ошибка запуска", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        try {
            signInForm = findViewById(R.id.signInForm);
            signUpForm = findViewById(R.id.signUpForm);
            signInTabButton = findViewById(R.id.signInTabButton);
            signUpTabButton = findViewById(R.id.signUpTabButton);
            emailEditText = findViewById(R.id.emailEditText);
            passwordEditText = findViewById(R.id.passwordEditText);
            signInButton = findViewById(R.id.signInButton);
            signUpFullNameEditText = findViewById(R.id.signUpFullNameEditText);
            signUpUsernameEditText = findViewById(R.id.signUpUsernameEditText);
            signUpEmailEditText = findViewById(R.id.signUpEmailEditText);
            signUpPasswordEditText = findViewById(R.id.signUpPasswordEditText);
            genderRadioGroup = findViewById(R.id.genderRadioGroup);
            birthDateButton = findViewById(R.id.birthDateButton);
            signUpButton = findViewById(R.id.signUpButton);
            selectedDateText = findViewById(R.id.selectedDateText);
            weightValueText = findViewById(R.id.weightValueText);
            heightValueText = findViewById(R.id.heightValueText);
            weightSeekBar = findViewById(R.id.weightSeekBar);
            heightSeekBar = findViewById(R.id.heightSeekBar);
            fitnessLevelSpinner = findViewById(R.id.fitnessLevelSpinner);
            progressBar = findViewById(R.id.progressBar);
            birthDateCalendar = Calendar.getInstance();
            dateFormatter = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        } catch (Exception e) {
            Log.e("AuthActivity", "initViews: " + e.getMessage(), e);
            throw new RuntimeException("Ошибка инициализации вьюх: " + e.getMessage(), e);
        }
    }

    private void initViewModel() {
        authViewModel = new ViewModelProvider(this).get(AuthViewModel.class);
    }

    private void setupUI() {
        signInTabButton.setOnClickListener(v -> switchToSignIn());
        signUpTabButton.setOnClickListener(v -> switchToSignUp());
        signInButton.setOnClickListener(v -> attemptSignIn());
        signUpButton.setOnClickListener(v -> attemptSignUp());
        birthDateButton.setOnClickListener(v -> showDatePickerDialog());

        // SeekBar вес 40-120
        weightSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int weight = progress + 40;
                weightValueText.setText(String.valueOf(weight));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // SeekBar рост 140-210
        heightSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int height = progress + 140;
                heightValueText.setText(String.valueOf(height));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Spinner уровень подготовки
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.fitness_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fitnessLevelSpinner.setAdapter(adapter);

        setupEmailValidation(signUpEmailEditText);
        setupEmailValidation(emailEditText);
        setupObservers();

        // Значения по умолчанию
        weightSeekBar.setProgress(30); // 70 кг
        heightSeekBar.setProgress(30); // 170 см
        fitnessLevelSpinner.setSelection(0);
        genderRadioGroup.check(R.id.genderMale);
    }

    private void switchToSignIn() {
        isSignUpMode = false;
        updateUI();
    }

    private void switchToSignUp() {
        isSignUpMode = true;
        updateUI();
    }

    private void updateUI() {
        if (isSignUpMode) {
            signInForm.setVisibility(View.GONE);
            signUpForm.setVisibility(View.VISIBLE);
            signInTabButton.setSelected(false);
            signUpTabButton.setSelected(true);
        } else {
            signInForm.setVisibility(View.VISIBLE);
            signUpForm.setVisibility(View.GONE);
            signInTabButton.setSelected(true);
            signUpTabButton.setSelected(false);
        }
        updateTabAppearance();
    }

    private void updateTabAppearance() {
        signInTabButton.post(() -> signInTabButton.setSelected(signInTabButton.isSelected()));
        signUpTabButton.post(() -> signUpTabButton.setSelected(signUpTabButton.isSelected()));
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    birthDateCalendar.set(Calendar.YEAR, year);
                    birthDateCalendar.set(Calendar.MONTH, month);
                    birthDateCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    String selectedDate = dateFormatter.format(birthDateCalendar.getTime());
                    selectedDateText.setText(selectedDate);
                    selectedDateText.setTextColor(ContextCompat.getColor(this, R.color.sport_primary));
                },
                birthDateCalendar.get(Calendar.YEAR),
                birthDateCalendar.get(Calendar.MONTH),
                birthDateCalendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void setupEmailValidation(EditText editText) {
        editText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) validateEmailFormat(editText.getText().toString().trim());
        });
        editText.setOnKeyListener((v, keyCode, event) -> {
            new Handler().postDelayed(() -> {
                String currentText = editText.getText().toString();
                if (!currentText.equals(currentText.toLowerCase())) {
                    editText.setError("Email должен быть строчными буквами");
                } else {
                    editText.setError(null);
                }
            }, 100);
            return false;
        });
    }

    private void attemptSignIn() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        Log.d("AuthActivity", "Попытка входа");
        if (validateSignInInput(email, password)) {
            authViewModel.signIn(email, password);
        }
    }

    private void attemptSignUp() {
        String fullName = signUpFullNameEditText.getText().toString().trim();
        String username = signUpUsernameEditText.getText().toString().trim();
        String email = signUpEmailEditText.getText().toString().trim();
        String password = signUpPasswordEditText.getText().toString().trim();
        String gender = getSelectedGender();
        String dateOfBirth = null;

        if (birthDateCalendar != null && !selectedDateText.getText().toString().equals("Выберите дату")) {
            SimpleDateFormat dbFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            dateOfBirth = dbFormat.format(birthDateCalendar.getTime());
        }

        double weight = weightSeekBar.getProgress() + 40.0;
        double height = heightSeekBar.getProgress() + 140.0;
        String fitnessLevelDisplay = fitnessLevelSpinner.getSelectedItem().toString();
        String fitnessLevelDb = convertFitnessLevelToDb(fitnessLevelDisplay);

        if (validateSignUpInput(fullName, username, email, password, gender, dateOfBirth)) {
            authViewModel.signUp(email, password, username, fullName, gender, dateOfBirth, weight, height, fitnessLevelDb);
        }
    }

    private String getSelectedGender() {
        int selectedId = genderRadioGroup.getCheckedRadioButtonId();
        if (selectedId == R.id.genderMale) return "male";
        else if (selectedId == R.id.genderFemale) return "female";
        return "male";
    }

    private String convertFitnessLevelToDb(String displayLevel) {
        switch (displayLevel) {
            case "Начинающий": return "beginner";
            case "Средний": return "intermediate";
            case "Продвинутый": return "advanced";
            default: return "beginner";
        }
    }

    private boolean validateSignInInput(String email, String password) {
        if (!validateEmailFormat(email)) return false;
        if (password.isEmpty() || password.length() < 6) {
            showError("Пароль должен быть не менее 6 символов");
            return false;
        }
        return true;
    }

    private boolean validateSignUpInput(String fullName, String username, String email,
                                        String password, String gender, String dateOfBirth) {
        if (fullName.isEmpty()) { showError("Введите полное имя"); return false; }
        if (username.isEmpty()) { showError("Введите имя пользователя"); return false; }
        if (username.length() < 3) { showError("Имя пользователя минимум 3 символа"); return false; }
        if (username.matches(".*[!,.'?].*")) { showError("Имя пользователя содержит запрещённые символы"); return false; }
        if (!validateEmailFormat(email)) return false;
        if (password.isEmpty() || password.length() < 6) { showError("Пароль должен быть не менее 6 символов"); return false; }
        if (dateOfBirth == null) { showError("Выберите дату рождения"); return false; }
        return true;
    }

    private boolean validateEmailFormat(String email) {
        if (email.isEmpty()) { showError("Введите email"); return false; }
        if (!email.equals(email.toLowerCase())) { showError("Email должен быть строчными буквами"); return false; }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { showError("Неверный формат email"); return false; }
        String emailDomain = email.substring(email.indexOf('@') + 1);
        boolean isAllowed = false;
        for (String domain : allowedEmailDomains) {
            if (emailDomain.equals(domain)) { isAllowed = true; break; }
        }
        if (!isAllowed) {
            showError("Разрешены только Gmail, Yandex, Mail и другие популярные домены");
            return false;
        }
        return true;
    }

    private void setupObservers() {
        authViewModel.getAuthResult().observe(this, resource -> {
            if (resource == null) return;
            switch (resource.status) {
                case LOADING:
                    showProgress(true);
                    new Handler().postDelayed(() -> {
                        if (progressBar.getVisibility() == View.VISIBLE) {
                            showProgress(false);
                            showError("Превышено время ожидания. Попробуйте снова.");
                        }
                    }, 10000);
                    break;
                case SUCCESS:
                    showProgress(false);
                    handleAuthSuccess(resource.data);
                    break;
                case ERROR:
                    showProgress(false);
                    showError(resource.message);
                    Log.e("AuthActivity", "Auth error: " + resource.message);
                    break;
            }
        });
    }

    private void handleAuthSuccess(Profile profile) {
        try {
            if (profile != null) {
                String message = isSignUpMode ? "Регистрация успешна! Добро пожаловать!" : "Добро пожаловать!";
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

                if (profile.getId() == null) {
                    showError("Ошибка: ID профиля не найден");
                    return;
                }
                if (profile.getUsername() == null) profile.setUsername("Спортсмен");

                // ✅ Сохраняем профиль и флаг логина
                SharedPreferencesManager prefsManager = SharedPreferencesManager.getInstance(this);
                prefsManager.setLoggedIn(true);
                prefsManager.saveUserProfile(profile);

                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("profile", profile);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            } else {
                showError("Ошибка: профиль не найден");
            }
        } catch (Exception e) {
            Log.e("AuthActivity", "handleAuthSuccess: " + e.getMessage(), e);
            showError(e.getMessage());
        }
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        signInButton.setEnabled(!show);
        signUpButton.setEnabled(!show);
        signInTabButton.setEnabled(!show);
        signUpTabButton.setEnabled(!show);
        if (show) {
            signInButton.setText("Загрузка...");
            signUpButton.setText("Загрузка...");
        } else {
            signInButton.setText("Войти");
            signUpButton.setText("Зарегистрироваться");
        }
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        Log.e("AuthActivity", "Error: " + message);
    }
}
