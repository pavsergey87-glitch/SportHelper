package com.example.sporthelper.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sporthelper.R;
import com.example.sporthelper.fragment.ChatListFragment;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.google.android.material.appbar.MaterialToolbar;

public class ChatListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Profile currentUser = SharedPreferencesManager.getInstance(this).getUserProfile();
        if (currentUser == null || currentUser.getId() == null) {
            Intent intent = new Intent(this, AuthActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            overridePendingTransition(0, 0);
            finish();
            return;
        }

        setContentView(R.layout.activity_chat_list);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle("Чаты");
            setSupportActionBar(toolbar);
            toolbar.post(() -> {
                if (toolbar.getOverflowIcon() != null) {
                    toolbar.getOverflowIcon().mutate().setTint(android.graphics.Color.WHITE);
                }
            });
            toolbar.setNavigationOnClickListener(v -> {
                finish();
                overridePendingTransition(0, 0);
            });
        }

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainer, new ChatListFragment(), "chat_list_fragment")
                    .commit();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(0, 0);
    }
}