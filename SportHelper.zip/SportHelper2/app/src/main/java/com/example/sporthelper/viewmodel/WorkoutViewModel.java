package com.example.sporthelper.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Resource;
import com.example.sporthelper.model.Workout;
import com.example.sporthelper.repository.WorkoutRepository;

import java.util.List;

public class WorkoutViewModel extends AndroidViewModel {

    private final WorkoutRepository workoutRepository;
    private final MutableLiveData<Resource<List<Workout>>> workouts = new MutableLiveData<>();
    private final MutableLiveData<Resource<Workout>> addWorkoutResult = new MutableLiveData<>();

    public WorkoutViewModel(@NonNull Application application) {
        super(application);
        this.workoutRepository = new WorkoutRepository(application.getApplicationContext());
    }

    public void loadWorkouts(Long userId, String workoutDate) {
        workoutRepository.getWorkoutsByUserAndDate(userId, workoutDate).observeForever(result -> {
            workouts.postValue(result);
        });
    }

    public void addWorkout(
            Long userId,
            String workoutName,
            String workoutDate,
            Integer durationMinutes,
            Integer caloriesBurned,
            String notes
    ) {
        workoutRepository.addWorkout(
                userId,
                workoutName,
                workoutDate,
                durationMinutes,
                caloriesBurned,
                notes
        ).observeForever(result -> addWorkoutResult.postValue(result));
    }

    public LiveData<Resource<List<Workout>>> getWorkouts() {
        return workouts;
    }

    public LiveData<Resource<Workout>> getAddWorkoutResult() {
        return addWorkoutResult;
    }
}