package com.example.sporthelper.model;

import java.io.Serializable;

public class Message implements Serializable {

    private Long    id;
    private Long    chatId;
    private Long    senderId;
    private String  content;
    private String  createdAt;
    private boolean isEdited;
    private Long    replyToId;
    private String  senderUsername;
    private String  replyToText;
    private String  replyToUsername;

    public Message() {}

    // ========== GETTERS ==========

    public Long getId()                  { return id; }
    public Long getChatId()              { return chatId; }
    public Long getSenderId()            { return senderId; }
    public String getContent()           { return content; }
    public String getCreatedAt()         { return createdAt; }
    public boolean isEdited()            { return isEdited; }
    public Long getReplyToId()           { return replyToId; }
    public String getSenderUsername()    { return senderUsername; }
    public String getReplyToText()       { return replyToText; }
    public String getReplyToUsername()   { return replyToUsername; }

    // ========== SETTERS ==========

    public void setId(Long id)                          { this.id = id; }
    public void setChatId(Long chatId)                  { this.chatId = chatId; }
    public void setSenderId(Long senderId)              { this.senderId = senderId; }
    public void setContent(String content)              { this.content = content; }
    public void setCreatedAt(String createdAt)          { this.createdAt = createdAt; }
    public void setEdited(boolean edited)               { this.isEdited = edited; }
    public void setReplyToId(Long replyToId)            { this.replyToId = replyToId; }
    public void setSenderUsername(String username)      { this.senderUsername = username; }
    public void setReplyToText(String replyToText)      { this.replyToText = replyToText; }
    public void setReplyToUsername(String username)     { this.replyToUsername = username; }
}
