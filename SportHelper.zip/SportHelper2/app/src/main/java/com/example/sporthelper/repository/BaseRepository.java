package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class BaseRepository {

    protected static String SUPABASE_URL;
    protected static String SUPABASE_KEY;
    protected static String SUPABASE_REST_URL;

    protected OkHttpClient client;
    protected Gson gson;

    public BaseRepository(Context context) {
        SUPABASE_URL = "https://xgmmbiirwxjbgxgvlwir.supabase.co";
        SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhnbW1iaWlyd3hqYmd4Z3Zsd2lyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NjgyNDEsImV4cCI6MjA3OTE0NDI0MX0.80iGHcSPTxdMRBVZascHEssGEl0eTLTVcdK5pIW_Swg";
        SUPABASE_REST_URL = SUPABASE_URL + "/rest/v1/";

        this.client = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .callTimeout(75, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .protocols(java.util.Arrays.asList(Protocol.HTTP_1_1, Protocol.HTTP_2))
                .build();

        this.gson = new Gson();
    }

    protected Request createSupabaseRequest(String endpoint, String method, JsonObject data) {
        RequestBody body = null;

        if (data != null) {
            body = RequestBody.create(
                    data.toString(),
                    MediaType.parse("application/json")
            );
        }

        Request.Builder requestBuilder = new Request.Builder()
                .url(SUPABASE_REST_URL + endpoint)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation");

        if ("POST".equals(method) || "PUT".equals(method) || "PATCH".equals(method)) {
            requestBuilder.method(method, body);
        } else if ("DELETE".equals(method)) {
            requestBuilder.delete();
        } else {
            requestBuilder.get();
        }

        return requestBuilder.build();
    }

    protected String executeRequest(Request request) throws IOException {
        Response response = null;

        try {
            response = client.newCall(request).execute();

            Log.d("BaseRepository", "HTTP code: " + response.code());
            Log.d("BaseRepository", "URL: " + request.url());

            if (!response.isSuccessful()) {
                String errorBody = response.body() != null
                        ? response.body().string()
                        : "No error body";

                String errorMessage = "HTTP " + response.code()
                        + " " + response.message()
                        + " - " + errorBody;

                Log.e("BaseRepository", errorMessage);
                throw new IOException(errorMessage);
            }

            if (response.body() == null) {
                return "";
            }

            String responseBody = response.body().string();
            Log.d("BaseRepository", "Response: " + responseBody);
            return responseBody;

        } catch (SocketTimeoutException e) {
            Log.e("BaseRepository", "Timeout: " + e.getMessage(), e);
            throw new IOException("Превышено время ожидания ответа сервера", e);
        } catch (Exception e) {
            Log.e("BaseRepository", "executeRequest error: " + e.getMessage(), e);
            throw new IOException(e.getMessage(), e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
    }
}