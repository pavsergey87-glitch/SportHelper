package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Request;

public class ProfileRepository extends BaseRepository {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public ProfileRepository(Context context) {
        super(context);
    }

    public LiveData<Resource<Profile>> updateProfile(
            Long profileId,
            String username,
            String fullName,
            Double weight,
            Double height,
            String fitnessLevel
    ) {
        MutableLiveData<Resource<Profile>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                JsonObject body = new JsonObject();

                if (username != null) {
                    body.addProperty("username", username);
                }

                if (fullName != null) {
                    body.addProperty("full_name", fullName);
                }

                if (weight != null) {
                    body.addProperty("weight", weight);
                }

                if (height != null) {
                    body.addProperty("height", height);
                }

                if (fitnessLevel != null) {
                    body.addProperty("fitness_level", fitnessLevel);
                }

                String endpoint = "profiles?id=eq." + profileId + "&select=*";
                Request request = createSupabaseRequest(endpoint, "PATCH", body);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                if (jsonArray != null && jsonArray.size() > 0) {
                    JsonObject profileObj = jsonArray.get(0).getAsJsonObject();
                    Profile updatedProfile = parseProfile(profileObj);
                    result.postValue(Resource.success(updatedProfile));
                } else {
                    result.postValue(Resource.error("Не удалось обновить профиль", null));
                }

            } catch (Exception e) {
                Log.e("ProfileRepository", "Ошибка обновления профиля: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка обновления: " + e.getMessage(), null));
            }
        });

        return result;
    }

    private Profile parseProfile(JsonObject data) {
        Profile profile = new Profile();

        if (data.has("id") && !data.get("id").isJsonNull()) {
            profile.setId(data.get("id").getAsLong());
        }
        if (data.has("email") && !data.get("email").isJsonNull()) {
            profile.setEmail(data.get("email").getAsString());
        }
        if (data.has("username") && !data.get("username").isJsonNull()) {
            profile.setUsername(data.get("username").getAsString());
        }
        if (data.has("full_name") && !data.get("full_name").isJsonNull()) {
            profile.setFullName(data.get("full_name").getAsString());
        }
        if (data.has("fitness_level") && !data.get("fitness_level").isJsonNull()) {
            profile.setFitnessLevel(data.get("fitness_level").getAsString());
        }
        if (data.has("weight") && !data.get("weight").isJsonNull()) {
            profile.setWeight(data.get("weight").getAsDouble());
        }
        if (data.has("height") && !data.get("height").isJsonNull()) {
            profile.setHeight(data.get("height").getAsDouble());
        }
        if (data.has("password_hash") && !data.get("password_hash").isJsonNull()) {
            profile.setPasswordHash(data.get("password_hash").getAsString());
        }

        return profile;
    }
}