package com.example.sporthelper.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class MessageDateDividerUtils {

    private static final Locale RU_LOCALE = new Locale("ru");

    private MessageDateDividerUtils() {
    }

    public static String buildDayKey(String createdAt) {
        long timestamp = MessageTimeUtils.parseTimestamp(createdAt);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(timestamp));
    }

    public static String formatDayLabel(String createdAt) {
        long timestamp = MessageTimeUtils.parseTimestamp(createdAt);

        Calendar messageCalendar = Calendar.getInstance();
        messageCalendar.setTimeInMillis(timestamp);

        Calendar todayCalendar = Calendar.getInstance();
        if (isSameDay(messageCalendar, todayCalendar)) {
            return "Сегодня";
        }

        Calendar yesterdayCalendar = Calendar.getInstance();
        yesterdayCalendar.add(Calendar.DAY_OF_YEAR, -1);
        if (isSameDay(messageCalendar, yesterdayCalendar)) {
            return "Вчера";
        }

        return new SimpleDateFormat("d MMMM", RU_LOCALE).format(new Date(timestamp));
    }

    public static boolean isSameDay(String firstCreatedAt, String secondCreatedAt) {
        return buildDayKey(firstCreatedAt).equals(buildDayKey(secondCreatedAt));
    }

    private static boolean isSameDay(Calendar first, Calendar second) {
        return first.get(Calendar.YEAR) == second.get(Calendar.YEAR)
                && first.get(Calendar.DAY_OF_YEAR) == second.get(Calendar.DAY_OF_YEAR);
    }
}