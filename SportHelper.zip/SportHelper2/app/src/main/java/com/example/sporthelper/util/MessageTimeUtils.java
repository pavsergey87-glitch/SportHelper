package com.example.sporthelper.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class MessageTimeUtils {

    private static final Locale DEFAULT_LOCALE = Locale.getDefault();

    private MessageTimeUtils() {
    }

    public static String formatMessageTime(String createdAt) {
        long timestamp = parseTimestamp(createdAt);
        return new SimpleDateFormat("HH:mm", DEFAULT_LOCALE).format(new Date(timestamp));
    }

    public static long parseTimestamp(String createdAt) {
        if (createdAt == null || createdAt.trim().isEmpty()) {
            return System.currentTimeMillis();
        }

        String value = createdAt.trim();

        try {
            return parseIsoTimestamp(value);
        } catch (Exception ignored) {
        }

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            Date date = formatter.parse(value);
            if (date != null) {
                return date.getTime();
            }
        } catch (Exception ignored) {
        }

        try {
            return Long.parseLong(value);
        } catch (Exception ignored) {
        }

        return System.currentTimeMillis();
    }

    private static long parseIsoTimestamp(String value) throws Exception {
        String normalized = value;

        if (normalized.contains(" ")) {
            normalized = normalized.replace(" ", "T");
        }

        if (normalized.endsWith("Z")) {
            normalized = normalized.substring(0, normalized.length() - 1) + "+00:00";
        }

        int tIndex = normalized.indexOf('T');
        int plusIndex = normalized.lastIndexOf('+');
        int minusIndex = normalized.lastIndexOf('-');

        int zoneIndex = Math.max(plusIndex, minusIndex > tIndex ? minusIndex : -1);

        String mainPart;
        String zonePart;

        if (zoneIndex > tIndex) {
            mainPart = normalized.substring(0, zoneIndex);
            zonePart = normalized.substring(zoneIndex);
        } else {
            mainPart = normalized;
            zonePart = "";
        }

        if (mainPart.contains(".")) {
            int dotIndex = mainPart.indexOf('.');
            String prefix = mainPart.substring(0, dotIndex);
            String fraction = mainPart.substring(dotIndex + 1);

            if (fraction.length() > 3) {
                fraction = fraction.substring(0, 3);
            } else if (fraction.length() == 1) {
                fraction = fraction + "00";
            } else if (fraction.length() == 2) {
                fraction = fraction + "0";
            }

            mainPart = prefix + "." + fraction;
        }

        String finalValue = mainPart + zonePart;

        SimpleDateFormat formatter;
        if (mainPart.contains(".")) {
            formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US);
        } else if (!zonePart.isEmpty()) {
            formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
        } else {
            formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
        }

        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = formatter.parse(finalValue);

        if (date == null) {
            throw new IllegalArgumentException("Cannot parse date: " + value);
        }

        return date.getTime();
    }
}