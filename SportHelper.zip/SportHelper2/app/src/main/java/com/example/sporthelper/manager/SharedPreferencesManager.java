package com.example.sporthelper.manager;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.sporthelper.model.Profile;
import com.google.gson.Gson;

public class SharedPreferencesManager {

    private static final String PREF_NAME = "SportHelperPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_PROFILE = "userProfile";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_GLOBAL_CHAT_NOTIFICATIONS = "chat_notifications_global";
    private static final String KEY_OPEN_CHAT_ID = "open_chat_id";

    private static SharedPreferencesManager instance;
    private final SharedPreferences sharedPreferences;
    private final Gson gson;

    private SharedPreferencesManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public static synchronized SharedPreferencesManager getInstance(Context context) {
        if (instance == null) {
            instance = new SharedPreferencesManager(context.getApplicationContext());
        }
        return instance;
    }

    public SharedPreferences getSharedPreferences() {
        return sharedPreferences;
    }

    public void setLoggedIn(boolean isLoggedIn) {
        sharedPreferences.edit().putBoolean(KEY_IS_LOGGED_IN, isLoggedIn).apply();
    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public void saveUserProfile(Profile profile) {
        if (profile != null) {
            String profileJson = gson.toJson(profile);
            sharedPreferences.edit()
                    .putString(KEY_USER_PROFILE, profileJson)
                    .putLong(KEY_USER_ID, profile.getId() != null ? profile.getId() : -1)
                    .apply();
        }
    }

    public Profile getUserProfile() {
        String profileJson = sharedPreferences.getString(KEY_USER_PROFILE, null);
        if (profileJson != null) {
            return gson.fromJson(profileJson, Profile.class);
        }
        return null;
    }

    public Long getUserId() {
        return sharedPreferences.getLong(KEY_USER_ID, -1);
    }

    public void logout() {
        sharedPreferences.edit()
                .remove(KEY_IS_LOGGED_IN)
                .remove(KEY_USER_PROFILE)
                .remove(KEY_USER_ID)
                .remove(KEY_OPEN_CHAT_ID)
                .apply();
    }

    public boolean isChatNotificationsEnabled(Long chatId) {
        if (chatId == null) return true;
        return sharedPreferences.getBoolean("chat_notifications_" + chatId, true);
    }

    public void setChatNotificationsEnabled(Long chatId, boolean enabled) {
        if (chatId == null) return;
        sharedPreferences.edit()
                .putBoolean("chat_notifications_" + chatId, enabled)
                .apply();
    }

    public boolean areGlobalChatNotificationsEnabled() {
        return sharedPreferences.getBoolean(KEY_GLOBAL_CHAT_NOTIFICATIONS, true);
    }

    public void setGlobalChatNotificationsEnabled(boolean enabled) {
        sharedPreferences.edit().putBoolean(KEY_GLOBAL_CHAT_NOTIFICATIONS, enabled).apply();
    }

    public void setOpenChatId(Long chatId) {
        if (chatId == null) {
            sharedPreferences.edit().remove(KEY_OPEN_CHAT_ID).apply();
        } else {
            sharedPreferences.edit().putLong(KEY_OPEN_CHAT_ID, chatId).apply();
        }
    }

    public Long getOpenChatId() {
        if (!sharedPreferences.contains(KEY_OPEN_CHAT_ID)) return null;
        long value = sharedPreferences.getLong(KEY_OPEN_CHAT_ID, -1);
        return value == -1 ? null : value;
    }

    public void clearOpenChatId() {
        sharedPreferences.edit().remove(KEY_OPEN_CHAT_ID).apply();
    }
}