package com.example.sporthelper.util;

import com.example.sporthelper.model.ChatUiItem;
import com.example.sporthelper.model.Message;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public final class ChatDateUtils {

    private static final Locale RU_LOCALE = new Locale("ru");

    private ChatDateUtils() {
    }

    public static List<ChatUiItem> buildChatItems(List<Message> messages, Long currentUserId) {
        List<ChatUiItem> items = new ArrayList<>();
        Long previousTimestamp = null;

        if (messages == null) {
            return items;
        }

        for (Message message : messages) {
            long currentTimestamp = parseTimestamp(message.getCreatedAt());

            if (shouldShowDateHeader(previousTimestamp, currentTimestamp)) {
                items.add(ChatUiItem.date(formatDayHeader(currentTimestamp)));
            }

            boolean isMine = message.getSenderId() != null
                    && currentUserId != null
                    && message.getSenderId().equals(currentUserId);

            items.add(isMine ? ChatUiItem.sent(message) : ChatUiItem.received(message));
            previousTimestamp = currentTimestamp;
        }

        return items;
    }

    public static String formatMessageTime(String createdAt) {
        long timestamp = parseTimestamp(createdAt);
        return new SimpleDateFormat("HH:mm", RU_LOCALE).format(new Date(timestamp));
    }

    public static long parseTimestamp(String createdAt) {
        if (createdAt == null || createdAt.trim().isEmpty()) {
            return System.currentTimeMillis();
        }

        String value = createdAt.trim();

        try {
            return parseIsoTimestamp(value);
        } catch (Exception ignored) {
        }

        try {
            SimpleDateFormat localDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            Date date = localDateTime.parse(value);
            if (date != null) {
                return date.getTime();
            }
        } catch (Exception ignored) {
        }

        try {
            return Long.parseLong(value);
        } catch (Exception ignored) {
        }

        return System.currentTimeMillis();
    }

    private static long parseIsoTimestamp(String value) throws Exception {
        String normalized = value;

        if (normalized.contains(" ")) {
            normalized = normalized.replace(" ", "T");
        }

        if (normalized.endsWith("Z")) {
            normalized = normalized.substring(0, normalized.length() - 1) + "+00:00";
        }

        int tIndex = normalized.indexOf('T');
        int plusIndex = normalized.lastIndexOf('+');
        int minusIndex = normalized.lastIndexOf('-');

        int zoneIndex = Math.max(plusIndex, minusIndex > tIndex ? minusIndex : -1);

        String mainPart;
        String zonePart;

        if (zoneIndex > tIndex) {
            mainPart = normalized.substring(0, zoneIndex);
            zonePart = normalized.substring(zoneIndex);
        } else {
            mainPart = normalized;
            zonePart = "";
        }

        if (mainPart.contains(".")) {
            int dotIndex = mainPart.indexOf('.');
            String prefix = mainPart.substring(0, dotIndex);
            String fraction = mainPart.substring(dotIndex + 1);

            if (fraction.length() > 3) {
                fraction = fraction.substring(0, 3);
            } else if (fraction.length() == 1) {
                fraction = fraction + "00";
            } else if (fraction.length() == 2) {
                fraction = fraction + "0";
            }

            mainPart = prefix + "." + fraction;
        }

        String finalValue = mainPart + zonePart;

        SimpleDateFormat formatter;
        if (mainPart.contains(".")) {
            formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US);
        } else {
            formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
        }

        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = formatter.parse(finalValue);

        if (date == null) {
            throw new IllegalArgumentException("Cannot parse date: " + value);
        }

        return date.getTime();
    }

    public static boolean shouldShowDateHeader(Long previousTimestamp, long currentTimestamp) {
        if (previousTimestamp == null) {
            return true;
        }

        Calendar prev = Calendar.getInstance();
        Calendar cur = Calendar.getInstance();

        prev.setTimeInMillis(previousTimestamp);
        cur.setTimeInMillis(currentTimestamp);

        return prev.get(Calendar.YEAR) != cur.get(Calendar.YEAR)
                || prev.get(Calendar.DAY_OF_YEAR) != cur.get(Calendar.DAY_OF_YEAR);
    }

    public static String formatDayHeader(long timestamp) {
        Calendar now = Calendar.getInstance();
        Calendar msg = Calendar.getInstance();
        msg.setTimeInMillis(timestamp);

        if (isSameDay(now, msg)) {
            return "Сегодня";
        }

        Calendar yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DAY_OF_YEAR, -1);
        if (isSameDay(yesterday, msg)) {
            return "Вчера";
        }

        if (now.get(Calendar.YEAR) == msg.get(Calendar.YEAR)) {
            return new SimpleDateFormat("d MMMM", RU_LOCALE).format(new Date(timestamp));
        }

        return new SimpleDateFormat("d MMMM yyyy", RU_LOCALE).format(new Date(timestamp));
    }

    private static boolean isSameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
                && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }
}