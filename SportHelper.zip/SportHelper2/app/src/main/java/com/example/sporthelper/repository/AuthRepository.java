package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Request;

public class AuthRepository extends BaseRepository {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Gson gson = new Gson();

    public AuthRepository(Context context) {
        super(context);
    }

    public Resource<Profile> signUpSync(String email, String password, String username,
                                        String fullName, String gender, String dateOfBirth,
                                        double weight, double height, String fitnessLevel) {
        try {
            String normalizedEmail = email.toLowerCase();
            Log.d("AuthRepository", "signUpSync: email=" + normalizedEmail + " username=" + username);

            JsonObject profileData = new JsonObject();
            profileData.addProperty("email", normalizedEmail);
            profileData.addProperty("username", username);
            profileData.addProperty("password_hash", password);
            profileData.addProperty("full_name", fullName);
            profileData.addProperty("gender", gender);
            profileData.addProperty("date_of_birth", dateOfBirth);
            profileData.addProperty("weight", weight);
            profileData.addProperty("height", height);
            profileData.addProperty("fitness_level", fitnessLevel);

            String endpoint = "profiles?select=*";
            Request request = createSupabaseRequest(endpoint, "POST", profileData);
            Log.d("AuthRepository", "POST endpoint: " + endpoint);
            Log.d("AuthRepository", "POST body: " + profileData);

            String response = executeRequest(request);
            Log.d("AuthRepository", "POST response: " + response);

            JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
            if (jsonArray.size() > 0) {
                JsonObject createdProfile = jsonArray.get(0).getAsJsonObject();
                Profile profile = parseProfile(createdProfile);
                Log.d("AuthRepository", "Регистрация успешна, ID=" + profile.getId());
                return Resource.success(profile);
            } else {
                Log.e("AuthRepository", "Пустой ответ при регистрации");
                return Resource.error("Ошибка регистрации: пустой ответ", null);
            }
        } catch (Exception e) {
            Log.e("AuthRepository", "ОШИБКА РЕГИСТРАЦИИ: " + e.getMessage(), e);
            return Resource.error("Ошибка регистрации: " + e.getMessage(), null);
        }
    }

    public Resource<Profile> signInSync(String email, String password) {
        try {
            String normalizedEmail = email.toLowerCase();
            Log.d("AuthRepository", "signInSync: email=" + normalizedEmail);

            String endpoint = "profiles?email=eq." + normalizedEmail + "&select=*";
            Request request = createSupabaseRequest(endpoint, "GET", null);
            String response = executeRequest(request);
            Log.d("AuthRepository", "GET response: " + response);

            JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
            if (jsonArray.size() > 0) {
                JsonObject profileData = jsonArray.get(0).getAsJsonObject();

                if (!profileData.has("password_hash") || profileData.get("password_hash").isJsonNull()) {
                    Log.e("AuthRepository", "password_hash отсутствует или null");
                    return Resource.error("Ошибка: данные профиля повреждены", null);
                }

                String storedPassword = profileData.get("password_hash").getAsString();
                Log.d("AuthRepository", "Проверка пароля...");

                if (storedPassword.equals(password)) {
                    Profile profile = parseProfile(profileData);
                    Log.d("AuthRepository", "Вход успешен, ID=" + profile.getId());
                    return Resource.success(profile);
                } else {
                    Log.e("AuthRepository", "Неверный пароль");
                    return Resource.error("Неверный пароль", null);
                }
            } else {
                Log.e("AuthRepository", "Пользователь не найден: " + normalizedEmail);
                return Resource.error("Пользователь с таким email не найден", null);
            }
        } catch (Exception e) {
            Log.e("AuthRepository", "ОШИБКА ВХОДА: " + e.getMessage(), e);
            return Resource.error("Ошибка входа: " + e.getMessage(), null);
        }
    }

    public LiveData<Resource<Profile>> signUp(String email, String password, String username,
                                              String fullName, String gender, String dateOfBirth,
                                              double weight, double height, String fitnessLevel) {
        MutableLiveData<Resource<Profile>> result = new MutableLiveData<>();
        executor.execute(() -> {
            Resource<Profile> resource = signUpSync(email, password, username, fullName,
                    gender, dateOfBirth, weight, height, fitnessLevel);
            result.postValue(resource);
        });
        return result;
    }

    public LiveData<Resource<Profile>> signIn(String email, String password) {
        MutableLiveData<Resource<Profile>> result = new MutableLiveData<>();
        executor.execute(() -> {
            Resource<Profile> resource = signInSync(email, password);
            result.postValue(resource);
        });
        return result;
    }

    public LiveData<Resource<Boolean>> checkUserExists(String email) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();
        executor.execute(() -> {
            try {
                String normalizedEmail = email.toLowerCase();
                String endpoint = "profiles?email=eq." + normalizedEmail + "&select=id";
                Request request = createSupabaseRequest(endpoint, "GET", null);
                String response = executeRequest(request);
                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                boolean userExists = jsonArray.size() > 0;
                Log.d("AuthRepository", "checkUserExists: " + normalizedEmail + " = " + userExists);
                result.postValue(Resource.success(userExists));
            } catch (Exception e) {
                Log.e("AuthRepository", "checkUserExists error: " + e.getMessage(), e);
                result.postValue(Resource.error(e.getMessage(), null));
            }
        });
        return result;
    }

    private Profile parseProfile(JsonObject data) {
        Profile profile = new Profile();
        if (data.has("id") && !data.get("id").isJsonNull())
            profile.setId(data.get("id").getAsLong());
        if (data.has("email") && !data.get("email").isJsonNull())
            profile.setEmail(data.get("email").getAsString());
        if (data.has("username") && !data.get("username").isJsonNull())
            profile.setUsername(data.get("username").getAsString());
        if (data.has("full_name") && !data.get("full_name").isJsonNull())
            profile.setFullName(data.get("full_name").getAsString());
        if (data.has("fitness_level") && !data.get("fitness_level").isJsonNull())
            profile.setFitnessLevel(data.get("fitness_level").getAsString());
        if (data.has("weight") && !data.get("weight").isJsonNull())
            profile.setWeight(data.get("weight").getAsDouble());
        if (data.has("height") && !data.get("height").isJsonNull())
            profile.setHeight(data.get("height").getAsDouble());
        if (data.has("password_hash") && !data.get("password_hash").isJsonNull())
            profile.setPasswordHash(data.get("password_hash").getAsString());
        return profile;
    }
}
