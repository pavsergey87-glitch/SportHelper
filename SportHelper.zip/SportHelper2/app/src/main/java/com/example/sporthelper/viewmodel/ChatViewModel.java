package com.example.sporthelper.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Chat;
import com.example.sporthelper.model.Message;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.repository.ChatRepository;

import java.util.List;

public class ChatViewModel extends AndroidViewModel {

    private final ChatRepository chatRepository;

    private final MutableLiveData<Resource<List<Chat>>> chats = new MutableLiveData<>();
    private final MutableLiveData<Resource<List<Message>>> messages = new MutableLiveData<>();
    private final MutableLiveData<Resource<Message>> sendResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Boolean>> deleteResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Boolean>> editResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Long>> findUserResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Chat>> createChatResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Boolean>> joinResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<List<String>>> membersResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<String>> inviteCodeResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Boolean>> updateGroupResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Boolean>> leaveChatResult = new MutableLiveData<>();
    private final MutableLiveData<Resource<Boolean>> deleteGroupResult = new MutableLiveData<>();

    public ChatViewModel(@NonNull Application application) {
        super(application);
        chatRepository = new ChatRepository(application.getApplicationContext());
    }

    public LiveData<Resource<List<Chat>>> getChats() {
        return chats;
    }

    public LiveData<Resource<List<Message>>> getMessages() {
        return messages;
    }

    public LiveData<Resource<Message>> getSendResult() {
        return sendResult;
    }

    public LiveData<Resource<Boolean>> getDeleteResult() {
        return deleteResult;
    }

    public LiveData<Resource<Boolean>> getEditResult() {
        return editResult;
    }

    public LiveData<Resource<Long>> getFindUserResult() {
        return findUserResult;
    }

    public LiveData<Resource<Chat>> getCreateChatResult() {
        return createChatResult;
    }

    public LiveData<Resource<Boolean>> getJoinResult() {
        return joinResult;
    }

    public LiveData<Resource<List<String>>> getMembersResult() {
        return membersResult;
    }

    public LiveData<Resource<String>> getInviteCodeResult() {
        return inviteCodeResult;
    }

    public LiveData<Resource<Boolean>> getUpdateGroupResult() {
        return updateGroupResult;
    }

    public LiveData<Resource<Boolean>> getLeaveChatResult() {
        return leaveChatResult;
    }

    public LiveData<Resource<Boolean>> getDeleteGroupResult() {
        return deleteGroupResult;
    }

    public void loadChats(Long userId) {
        chats.setValue(Resource.loading(null));
        chatRepository.getChatsForUser(userId)
                .observeForever(result -> chats.postValue(result));
    }

    public void findUserByUsername(String username) {
        findUserResult.setValue(Resource.loading(null));
        chatRepository.findUserByUsername(username)
                .observeForever(result -> findUserResult.postValue(result));
    }

    public void createPrivateChat(Long currentUserId, Long targetUserId) {
        createChatResult.setValue(Resource.loading(null));
        chatRepository.createPrivateChat(currentUserId, targetUserId)
                .observeForever(result -> createChatResult.postValue(result));
    }

    public void createGroupChat(Long creatorId, String groupName) {
        createChatResult.setValue(Resource.loading(null));
        chatRepository.createGroupChat(creatorId, groupName)
                .observeForever(result -> createChatResult.postValue(result));
    }

    public void joinChatByCode(Long userId, String code) {
        joinResult.setValue(Resource.loading(null));
        chatRepository.joinChatByCode(userId, code)
                .observeForever(result -> joinResult.postValue(result));
    }

    public void loadChatMembers(Long chatId) {
        membersResult.setValue(Resource.loading(null));
        chatRepository.getChatMembers(chatId)
                .observeForever(result -> membersResult.postValue(result));
    }

    public void getInviteCode(Long chatId) {
        inviteCodeResult.setValue(Resource.loading(null));
        chatRepository.getInviteCode(chatId)
                .observeForever(result -> inviteCodeResult.postValue(result));
    }

    public void loadMessages(Long chatId) {
        messages.setValue(Resource.loading(null));
        chatRepository.getMessages(chatId)
                .observeForever(result -> messages.postValue(result));
    }

    public void sendMessage(Long chatId, Long senderId, String text, Long replyToId) {
        sendResult.setValue(Resource.loading(null));
        chatRepository.sendMessage(chatId, senderId, text, replyToId)
                .observeForever(result -> sendResult.postValue(result));
    }

    public void deleteMessage(Long messageId) {
        deleteResult.setValue(Resource.loading(null));
        chatRepository.deleteMessage(messageId)
                .observeForever(result -> deleteResult.postValue(result));
    }

    public void editMessage(Long messageId, String newText) {
        editResult.setValue(Resource.loading(null));
        chatRepository.editMessage(messageId, newText)
                .observeForever(result -> editResult.postValue(result));
    }

    public void updateGroupName(Long chatId, String newName) {
        updateGroupResult.setValue(Resource.loading(null));
        chatRepository.updateGroupName(chatId, newName)
                .observeForever(result -> updateGroupResult.postValue(result));
    }

    public void leaveChat(Long chatId, Long userId) {
        leaveChatResult.setValue(Resource.loading(null));
        chatRepository.leaveChat(chatId, userId)
                .observeForever(result -> leaveChatResult.postValue(result));
    }

    public void deleteGroup(Long chatId) {
        deleteGroupResult.setValue(Resource.loading(null));
        chatRepository.deleteGroup(chatId)
                .observeForever(result -> deleteGroupResult.postValue(result));
    }
}