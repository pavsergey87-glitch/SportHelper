package com.example.sporthelper.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.activity.MainActivity;
import com.example.sporthelper.activity.ProfileActivity;
import com.example.sporthelper.activity.SettingsActivity;
import com.example.sporthelper.adapter.WorkoutAdapter;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Workout;
import com.example.sporthelper.viewmodel.WorkoutViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class WorkoutFragment extends Fragment {

    private WorkoutViewModel workoutViewModel;
    private WorkoutAdapter workoutAdapter;
    private Profile currentUser;

    private MaterialToolbar toolbar;
    private TextView totalWorkoutsText;
    private TextView totalCaloriesText;
    private TextView totalMinutesText;
    private TextView currentDateText;
    private RecyclerView workoutsRecyclerView;
    private MaterialButton addWorkoutButton;
    private View prevDayButton;
    private View nextDayButton;
    private View emptyState;

    private LocalDate selectedDate;

    private final DateTimeFormatter uiFormatter =
            DateTimeFormatter.ofPattern("d MMMM", new Locale("ru"));

    public WorkoutFragment() {
        super(R.layout.fragment_workout);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (currentUser != null && currentUser.getId() != null) {
            loadWorkouts();
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        currentUser = SharedPreferencesManager.getInstance(requireContext()).getUserProfile();
        if (currentUser == null || currentUser.getId() == null) {
            Toast.makeText(requireContext(), "Ошибка авторизации", Toast.LENGTH_SHORT).show();
            return;
        }

        selectedDate = LocalDate.now();

        initViews(view);
        initViewModel();
        setupToolbar();
        setupRecyclerView();
        setupUI();
        setupObservers();
        updateDateText();
        loadWorkouts();
    }

    private void initViews(@NonNull View view) {
        toolbar = view.findViewById(R.id.toolbar);
        totalWorkoutsText = view.findViewById(R.id.totalWorkoutsText);
        totalCaloriesText = view.findViewById(R.id.totalCaloriesText);
        totalMinutesText = view.findViewById(R.id.totalMinutesText);
        currentDateText = view.findViewById(R.id.currentDateText);
        workoutsRecyclerView = view.findViewById(R.id.workoutsRecyclerView);
        addWorkoutButton = view.findViewById(R.id.addWorkoutButton);
        prevDayButton = view.findViewById(R.id.prevDayButton);
        nextDayButton = view.findViewById(R.id.nextDayButton);
        emptyState = view.findViewById(R.id.emptyState);
    }

    private void initViewModel() {
        workoutViewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);
    }

    private void setupToolbar() {
        boolean insideMain = requireActivity() instanceof MainActivity;

        if (!insideMain) {
            toolbar.setVisibility(View.GONE);
            return;
        }

        toolbar.setVisibility(View.VISIBLE);
        toolbar.setTitle("SportHelper");

        toolbar.post(() -> {
            if (toolbar.getOverflowIcon() != null) {
                toolbar.getOverflowIcon().mutate().setTint(Color.WHITE);
            }
        });

        toolbar.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.action_profile) {
                Intent intent = new Intent(requireContext(), ProfileActivity.class);
                startActivity(intent);
                requireActivity().overridePendingTransition(0, 0);
                return true;
            }

            if (itemId == R.id.action_settings) {
                Intent intent = new Intent(requireContext(), SettingsActivity.class);
                startActivity(intent);
                requireActivity().overridePendingTransition(0, 0);
                return true;
            }

            return false;
        });
    }

    private void setupRecyclerView() {
        workoutAdapter = new WorkoutAdapter(null, null);
        workoutsRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        workoutsRecyclerView.setAdapter(workoutAdapter);
    }

    private void setupUI() {
        prevDayButton.setOnClickListener(v -> {
            selectedDate = selectedDate.minusDays(1);
            updateDateText();
            loadWorkouts();
        });

        nextDayButton.setOnClickListener(v -> {
            selectedDate = selectedDate.plusDays(1);
            updateDateText();
            loadWorkouts();
        });

        addWorkoutButton.setOnClickListener(v -> showAddWorkoutDialog());
    }

    private void setupObservers() {
        workoutViewModel.getWorkouts().observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case SUCCESS:
                    updateWorkoutList(resource.data);
                    updateStats(resource.data);
                    break;

                case ERROR:
                    Toast.makeText(
                            requireContext(),
                            "Ошибка загрузки: " + resource.message,
                            Toast.LENGTH_SHORT
                    ).show();
                    updateWorkoutList(null);
                    updateStats(null);
                    break;

                case LOADING:
                    break;
            }
        });

        workoutViewModel.getAddWorkoutResult().observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case SUCCESS:
                    Toast.makeText(requireContext(), "Тренировка добавлена", Toast.LENGTH_SHORT).show();
                    loadWorkouts();
                    break;

                case ERROR:
                    Toast.makeText(
                            requireContext(),
                            resource.message != null ? resource.message : "Ошибка добавления тренировки",
                            Toast.LENGTH_SHORT
                    ).show();
                    break;

                case LOADING:
                    break;
            }
        });
    }

    private void loadWorkouts() {
        workoutViewModel.loadWorkouts(currentUser.getId(), selectedDate.toString());
    }

    private void updateDateText() {
        LocalDate today = LocalDate.now();
        LocalDate yesterday = today.minusDays(1);
        LocalDate tomorrow = today.plusDays(1);

        if (selectedDate.equals(today)) {
            currentDateText.setText("Сегодня");
        } else if (selectedDate.equals(yesterday)) {
            currentDateText.setText("Вчера");
        } else if (selectedDate.equals(tomorrow)) {
            currentDateText.setText("Завтра");
        } else {
            currentDateText.setText(selectedDate.format(uiFormatter));
        }
    }

    private void showAddWorkoutDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_workout, null);

        TextInputEditText workoutNameInput = dialogView.findViewById(R.id.workoutNameInput);
        TextInputEditText workoutDurationInput = dialogView.findViewById(R.id.workoutDurationInput);
        TextInputEditText workoutCaloriesInput = dialogView.findViewById(R.id.workoutCaloriesInput);
        TextInputEditText workoutDescriptionInput = dialogView.findViewById(R.id.workoutDescriptionInput);
        MaterialButton cancelButton = dialogView.findViewById(R.id.cancelButton);
        MaterialButton saveButton = dialogView.findViewById(R.id.saveButton);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String name = textOf(workoutNameInput);
            String durationText = textOf(workoutDurationInput);
            String caloriesText = textOf(workoutCaloriesInput);
            String notes = textOf(workoutDescriptionInput);

            if (name.isEmpty()) {
                Toast.makeText(requireContext(), "Введите название тренировки", Toast.LENGTH_SHORT).show();
                return;
            }

            if (durationText.isEmpty()) {
                Toast.makeText(requireContext(), "Введите длительность", Toast.LENGTH_SHORT).show();
                return;
            }

            if (caloriesText.isEmpty()) {
                Toast.makeText(requireContext(), "Введите калории", Toast.LENGTH_SHORT).show();
                return;
            }

            int durationMinutes;
            int caloriesBurned;

            try {
                durationMinutes = Integer.parseInt(durationText);
                caloriesBurned = Integer.parseInt(caloriesText);
            } catch (Exception e) {
                Toast.makeText(requireContext(), "Проверьте числовые поля", Toast.LENGTH_SHORT).show();
                return;
            }

            workoutViewModel.addWorkout(
                    currentUser.getId(),
                    name,
                    selectedDate.toString(),
                    durationMinutes,
                    caloriesBurned,
                    notes
            );

            dialog.dismiss();
        });

        dialog.show();
    }

    private String textOf(TextInputEditText editText) {
        return editText.getText() != null ? editText.getText().toString().trim() : "";
    }

    private void updateWorkoutList(List<Workout> workouts) {
        boolean isEmpty = workouts == null || workouts.isEmpty();

        emptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        workoutsRecyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);

        workoutAdapter.updateWorkouts(isEmpty ? null : workouts);
    }

    private void updateStats(List<Workout> workouts) {
        if (workouts == null || workouts.isEmpty()) {
            totalWorkoutsText.setText("0");
            totalCaloriesText.setText("0");
            totalMinutesText.setText("0");
            return;
        }

        int totalWorkouts = workouts.size();
        int totalCalories = 0;
        int totalMinutes = 0;

        for (Workout workout : workouts) {
            if (workout.getCaloriesBurned() != null) {
                totalCalories += workout.getCaloriesBurned();
            }

            if (workout.getDurationMinutes() != null) {
                totalMinutes += workout.getDurationMinutes();
            }
        }

        totalWorkoutsText.setText(String.valueOf(totalWorkouts));
        totalCaloriesText.setText(String.valueOf(totalCalories));
        totalMinutesText.setText(String.valueOf(totalMinutes));
    }
}