package com.example.sporthelper.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.repository.ProfileRepository;

public class ProfileViewModel extends AndroidViewModel {

    private final ProfileRepository profileRepository;
    private final MutableLiveData<Resource<Profile>> updateProfileResult = new MutableLiveData<>();

    public ProfileViewModel(@NonNull Application application) {
        super(application);
        profileRepository = new ProfileRepository(application.getApplicationContext());
    }

    public void updateProfile(
            Long profileId,
            String username,
            String fullName,
            Double weight,
            Double height,
            String fitnessLevel
    ) {
        updateProfileResult.setValue(Resource.loading(null));
        profileRepository.updateProfile(profileId, username, fullName, weight, height, fitnessLevel)
                .observeForever(result -> updateProfileResult.postValue(result));
    }

    public LiveData<Resource<Profile>> getUpdateProfileResult() {
        return updateProfileResult;
    }
}