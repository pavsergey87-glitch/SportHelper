package com.example.sporthelper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.example.sporthelper.model.ChatUiItem;
import com.example.sporthelper.model.Message;
import com.example.sporthelper.util.ChatDateUtils;
import com.example.sporthelper.util.ChatListTimeUtils;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ChatUtilsTest {

    @Test
    public void buildChatItems_shouldAddOneDateHeader_forSameDayMessages() {
        List<Message> messages = new ArrayList<>();

        Message first = new Message();
        first.setId(1L);
        first.setSenderId(1L);
        first.setContent("Первое сообщение");
        first.setCreatedAt("2026-04-17T10:00:00Z");

        Message second = new Message();
        second.setId(2L);
        second.setSenderId(2L);
        second.setContent("Второе сообщение");
        second.setCreatedAt("2026-04-17T11:00:00Z");

        messages.add(first);
        messages.add(second);

        List<ChatUiItem> items = ChatDateUtils.buildChatItems(messages, 1L);

        assertEquals(3, items.size());
        assertEquals(ChatUiItem.TYPE_DATE, items.get(0).getType());
        assertEquals(ChatUiItem.TYPE_SENT, items.get(1).getType());
        assertEquals(ChatUiItem.TYPE_RECEIVED, items.get(2).getType());
    }

    @Test
    public void buildChatItems_shouldAddTwoDateHeaders_forDifferentDayMessages() {
        List<Message> messages = new ArrayList<>();

        Message first = new Message();
        first.setId(1L);
        first.setSenderId(1L);
        first.setContent("Сообщение 1");
        first.setCreatedAt("2026-04-17T10:00:00Z");

        Message second = new Message();
        second.setId(2L);
        second.setSenderId(2L);
        second.setContent("Сообщение 2");
        second.setCreatedAt("2026-04-18T10:00:00Z");

        messages.add(first);
        messages.add(second);

        List<ChatUiItem> items = ChatDateUtils.buildChatItems(messages, 1L);

        assertEquals(4, items.size());
        assertEquals(ChatUiItem.TYPE_DATE, items.get(0).getType());
        assertEquals(ChatUiItem.TYPE_SENT, items.get(1).getType());
        assertEquals(ChatUiItem.TYPE_DATE, items.get(2).getType());
        assertEquals(ChatUiItem.TYPE_RECEIVED, items.get(3).getType());
    }

    @Test
    public void formatChatListTime_shouldReturnTime_forToday() {
        Calendar calendar = Calendar.getInstance();

        String isoDate = String.format(
                Locale.US,
                "%04d-%02d-%02dT14:25:00Z",
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        String actual = ChatListTimeUtils.formatChatListTime(isoDate);

        assertTrue(actual.matches("\\d{2}:\\d{2}"));
    }

    @Test
    public void formatChatListTime_shouldReturnYesterday_forPreviousDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -1);

        String isoDate = String.format(
                Locale.US,
                "%04d-%02d-%02dT14:25:00Z",
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        String actual = ChatListTimeUtils.formatChatListTime(isoDate);

        assertEquals("Вчера", actual);
    }
}