package com.example.sporthelper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.example.sporthelper.util.MessageDateDividerUtils;
import com.example.sporthelper.util.MessageTimeUtils;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MessageTimeUtilsTest {

    @Test
    public void parseTimestamp_shouldReturnPositiveValue_forIsoDate() {
        String isoDate = "2026-04-17T10:15:30Z";

        long timestamp = MessageTimeUtils.parseTimestamp(isoDate);

        assertTrue(timestamp > 0);
    }

    @Test
    public void formatMessageTime_shouldReturnCorrectFormattedTime() {
        String isoDate = "2026-04-17T10:15:30Z";

        long timestamp = MessageTimeUtils.parseTimestamp(isoDate);
        String expected = new SimpleDateFormat("HH:mm", Locale.getDefault())
                .format(new Date(timestamp));

        String actual = MessageTimeUtils.formatMessageTime(isoDate);

        assertEquals(expected, actual);
    }

    @Test
    public void isSameDay_shouldReturnTrue_forSameDayDates() {
        String first = "2026-04-17 08:00:00";
        String second = "2026-04-17 12:30:00";

        boolean sameDay = MessageDateDividerUtils.isSameDay(first, second);

        assertTrue(sameDay);
    }

    @Test
    public void isSameDay_shouldReturnFalse_forDifferentDates() {
        String first = "2026-04-17 10:00:00";
        String second = "2026-04-18 10:00:00";

        boolean sameDay = MessageDateDividerUtils.isSameDay(first, second);

        assertFalse(sameDay);
    }

    @Test
    public void formatDayLabel_shouldReturnToday_forCurrentDate() {
        Calendar calendar = Calendar.getInstance();

        String isoDate = String.format(
                Locale.US,
                "%04d-%02d-%02dT12:00:00Z",
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        String label = MessageDateDividerUtils.formatDayLabel(isoDate);

        assertEquals("Сегодня", label);
    }

    @Test
    public void formatDayLabel_shouldReturnYesterday_forPreviousDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -1);

        String isoDate = String.format(
                Locale.US,
                "%04d-%02d-%02dT12:00:00Z",
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        String label = MessageDateDividerUtils.formatDayLabel(isoDate);

        assertEquals("Вчера", label);
    }
}