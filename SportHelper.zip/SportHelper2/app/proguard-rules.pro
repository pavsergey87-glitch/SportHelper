# Retrofit и OkHttp
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations

-keep class com.squareup.okhttp.** { *; }
-keep interface com.squareup.okhttp.** { *; }
-dontwarn com.squareup.okhttp.**

-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}

# Gson
-keep class com.google.gson.** { *; }
-keep class com.example.sporthelper.model.** { *; }

# AndroidX
-keep class androidx.** { *; }
-keep interface androidx.** { *; }

# Material Design
-keep class com.google.android.material.** { *; }

# Жизненный цикл и ViewModel
-keep class * extends androidx.lifecycle.ViewModel {
    public <methods>;
}

# Не обфусцируем наши модели данных
-keep class com.example.sporthelper.model.** { *; }
-keep class com.example.sporthelper.repository.** { *; }
-keep class com.example.sporthelper.viewmodel.** { *; }

# Общие правила
-keepattributes *Annotation*
-keepclassmembers class ** {
    @android.webkit.JavascriptInterface <methods>;
}

# Не предупреждать о некоторых вещах
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.jetbrains.annotations.**